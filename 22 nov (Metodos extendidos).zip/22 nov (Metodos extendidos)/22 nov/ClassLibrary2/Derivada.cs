﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace ClassLibrary2
{
    public class Derivada:Entidades.Externa.PersonaExterna
    {
        public Derivada(string nombre, string apellido, int edad,Entidades.Externa.ESexo sexo)
            :base(nombre,apellido,edad,sexo)
        {

        }


        public string ObtenerInfo()
        {
            return "Nombre: " + base._nombre + "\nApellido: " + base._apellido + "\nEdad: " + base._edad.ToString() + "\nSexo: " + base._sexo;
        }
    }
}
