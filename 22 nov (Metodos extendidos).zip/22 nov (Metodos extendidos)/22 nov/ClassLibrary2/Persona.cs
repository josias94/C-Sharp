﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2
{
    public class Persona
    {
        protected string _nombre;
        protected string _apellido;
        protected string _edad;
        protected ESexo _sexo;


        public string Nombre { get { return this._nombre; } }
        public string Apellido { get { return this._apellido; } }
        public string Edad { get { return this._edad; } }
        public string Sexo { get { return this._sexo.ToString(); } }

        //public Persona()
        //{

        //}

        public Persona(string nombre, string apellido , string edad, ESexo sexo)
            //:this()
        {
            this._nombre = nombre;
            this._apellido = apellido;
            this._edad = edad;
            this._sexo = sexo;
        }

        public string ObtenerInfo()
        {
            return "Nombre: " + this.Nombre + "\nApellido: " + this.Apellido + "\nEdad: " + this.Edad + "\nSexo: " + this.Sexo;
        }

    }
}
