﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary2;
using Entidades.Externa;
using Entidades.Externa.Sellada;

namespace ConsoleApplication1
{
    //para generar un metodo de extencion tiene que estar en una clase static
    static class Program
    {
        static void Main(string[] args)
        {
            Persona p1 = new Persona("Juan","Perez","23",ESexo.Masculino);
            Derivada p2 = new Derivada("Julian", "Perez", 32, Entidades.Externa.ESexo.Masculino);
            Entidades.Externa.Sellada.PersonaExternaSellada p3 = new Entidades.Externa.Sellada.PersonaExternaSellada("Juana", "Perez", 13, Entidades.Externa.Sellada.ESexo.Femenino);
            
            Console.WriteLine(p1.ObtenerInfo()+"\n");
            //clase base no tiene propiedades, la heredamos 
            //y hacemos un metodo en la clase heredada
            Console.WriteLine(p2.ObtenerInfo()+"\n");

            Console.WriteLine("Metodo Extencion\n\n"+p3.ObtenerInfoMain());
            Console.WriteLine("\nTRUE\n\n" + p3.ObtenerInfoMain(true));
            Console.WriteLine("\nfalse\n\n" + p3.ObtenerInfoMain(false));
            
            
            

            


            Console.ReadLine();
        }



        public static string ObtenerInfoMain(this PersonaExternaSellada p)
        {
            return "Nombre: " + p.Nombre + "\nApellido: " + p.Apellido + "\nEdad: " + p.Edad.ToString() + "\nSexo: " + p.Sexo.ToString();
        }


        public static string ObtenerInfoMain(this PersonaExternaSellada p, bool b)
        {
            if (b)
            {
                return ("Nombre: " + p.Nombre + "\nApellido: " + p.Apellido + "\nEdad: " + p.Edad.ToString() + "\nSexo: " + p.Sexo.ToString()).ToUpper();
            }
            else
            {
                return ("Nombre: " + p.Nombre + "\nApellido: " + p.Apellido + "\nEdad: " + p.Edad.ToString() + "\nSexo: " + p.Sexo.ToString()).ToLower();
            }
            
        }


        public static int CantidadDeCaracteres(this string cadena)
        {
            return cadena.Length;
        }


    }
}
