﻿using System;
using System.Xml.Serialization;//new
using System.IO;//new
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _25oct;

namespace ConsoleApplication1
{
    

    class Program
    {
        static void Main(string[] args)
        {
            string rutaDocumentos = Environment.GetFolderPath(Environment.SpecialFolder.Desktop); //donde esta logeado
            string rutaExe = AppDomain.CurrentDomain.BaseDirectory;

            
            Persona persona1 = new Persona("Josias", "Rivola");
            //si pongo el true no se sobreescribe en caso de que ya este creado
            //StreamWriter escritor = new StreamWriter(rutaExe + @"\personas.txt", true);
            //StreamWriter archivo = new StreamWriter("D:\\personas.txt", true);

            ////AppDomain.CurrentDomain.BaseDirectory retorna el lugar donde estoy
            
            ////@ sirve para que lea literal sin los //
            
            //escritor.WriteLine(persona1.ToString());
            //escritor.Close();
           
            //StreamReader archivoLectura = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + @"\personas.txt");
            //while (archivoLectura.EndOfStream == false)
            //{
            //    Console.WriteLine(archivoLectura.ReadLine());
            //}
            //archivoLectura.Close();

            //si uso el using se cierra el archivo solo
            //using(StreamReader l = new StreamReader(@"D:\personas.txt"))
            //{
            //    while (l.EndOfStream == false)
            //    {
            //        Console.WriteLine(l.ReadLine());
            //    }           
            //}
           

            //XML
            //XML
            //XML
            //XML
            TextReader lector;
            TextWriter escritor;
            List<Persona> lista = new List<Persona>();
            Persona p1 = new Persona("Persona", "Uno");
            Persona p2 = new Persona("Persona", "Dos");
            Persona p3 = new Persona("Persona", "Tres");

            Alumno a1 = new Alumno("josias", "rivola", 1);
            Alumno a2 = new Alumno("mica", "saez", 12);
            Alumno a3 = new Alumno("eze", "mahafud", 13);

            lista.Add(p1);
            lista.Add(p2);
            lista.Add(p3);

            lista.Add(a1);
            lista.Add(a2);
            lista.Add(a3);
            //XmlSerializer serializador=new XmlSerializer(typeof(Persona));
            ////necesita un constructor por defaul y ser publica
            ////escribir
            //escritor = new StreamWriter(rutaDocumentos + @"\personas.xml");       
            //serializador.Serialize(escritor, persona1);
            //escritor.Close();
            ////leer
            //lector = new StreamReader(rutaDocumentos + @"\personas.xml");
            //Persona persona2 = (Persona)serializador.Deserialize(lector);
            //Console.WriteLine(persona2.ToString());
            //lector.Close();
            XmlSerializer serializador = new XmlSerializer(typeof(List<Persona>));

            escritor = new StreamWriter(rutaDocumentos + @"\personas.xml");
            serializador.Serialize(escritor, lista);
            escritor.Close();
            //leer
            lector = new StreamReader(rutaDocumentos + @"\personas.xml");
            List<Persona> lista2 = (List<Persona>)serializador.Deserialize(lector);

            for (int i = 0; i < lista2.Count; i++)
            {
                Console.WriteLine(lista2[i].ToString());
            }
            lector.Close();


            
            
            Console.ReadLine();

        }
    }
}
