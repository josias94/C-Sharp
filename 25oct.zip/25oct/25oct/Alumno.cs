﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _25oct
{


    
    public class Alumno:Persona
    {
        #region Atributos
        public int _legajo;
        #endregion

        #region Constructores
        public Alumno()
        {

        }

        public Alumno(string nombre, string apellido, int legajo)
            :base(nombre,apellido)
        {
            this._legajo = legajo;
        }
        #endregion

        #region Propiedades

        #endregion
    }
}
