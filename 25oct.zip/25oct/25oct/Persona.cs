﻿using System;
using System.Xml.Serialization;//new
using System.IO;//new
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _25oct
{
    [XmlInclude(typeof(Alumno))]

    public class Persona
    {
        #region Atributos
        protected string _nombre;
        protected string _apellido;
        
        #endregion

        public string Nombre { get { return this._nombre; } set { this._nombre = value; } }
        public string Apellido { get { return this._apellido; } set { this._apellido = value; } }

        #region constructores
        public Persona() { }

        public Persona(string nombre, string apellido)
        {
            this._nombre = nombre;
            this._apellido = apellido;
        }
        #endregion

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Nombre: " + this.Nombre + " \nApellido: " + this.Apellido);
            return sb.ToString();
        }
    }
}
