﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using _25oct;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        Persona persona;
        OpenFileDialog abrirArchivo;
        SaveFileDialog guardarArchivo;

        
            
        public Form1()
        {
            InitializeComponent();
            persona = new Persona("Josias", "Rivola");
       
        }

        private void guardarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            

            this.guardarArchivo = new SaveFileDialog();
            this.guardarArchivo.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);


            if (this.guardarArchivo.ShowDialog() == DialogResult.OK)
            {
                StreamWriter escritor = new StreamWriter(this.guardarArchivo.FileName, true);
                escritor.WriteLine(persona.ToString());
                escritor.Close();
            }
        }

        private void leerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.abrirArchivo = new OpenFileDialog();
            if (this.abrirArchivo.ShowDialog() == DialogResult.OK)
            {
                string ms="";
                StreamReader archivoLectura = new StreamReader(this.abrirArchivo.FileName);
                while (archivoLectura.EndOfStream == false)
                {
                    ms+=archivoLectura.ReadLine();
                    //Console.WriteLine(0);
                }
                MessageBox.Show(ms);
                archivoLectura.Close();
            }
            
        }
    }
}
