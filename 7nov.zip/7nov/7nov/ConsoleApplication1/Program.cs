﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _7nov;
namespace ConsoleApplication1
{
    class Program
    {
        //debe tener la misma firma que el delegado
        //en este caso void y 0 parametros
        public static void Manejador()
        {
            Console.WriteLine("Estoy en el manejador de limite sueldo\n");
        }

       

        public static void ManejadorConEmpleado(Empleado empl)
        {
            Console.WriteLine("Empleado que quiso subirse el sueldo:\n");
            Console.WriteLine(empl.ToString());
        }

        public static void ManejadorConEmpleadoYSueldo(Empleado empl,double sueldo)
        {
            Console.WriteLine("Empleado que quiso subirse el sueldo:\n");
            Console.WriteLine(empl.ToString());
            Console.WriteLine("Y el sueldo que intento poner fue" + sueldo.ToString());
        }

        static void Main(string[] args)
        {
            Empleado empleado1 = new Empleado("Marcos", "Rey", 50);
            
            //Empleado empleado1 = new Empleado();

            //manejar el evento, le asigno a limite sueldo manejador
            //puedo asignar n metodos al evento
            //tengo que pasarle la dirençccion de memoria de una funcion
            empleado1.LimiteSueldo += new DelEmpl(Manejador);
            //manejador de instancia
            Program p = new Program();
            //empleado1.LimiteSueldo += new DelEmpl(p.ManejadorDos);

            empleado1.LimiteSueldoEmpleado += new DelConEmpl(ManejadorConEmpleado);

            empleado1.LimiteSueldoEmpleadoYSueldo += new DelConSueldo(ManejadorConEmpleadoYSueldo);


            Console.WriteLine(empleado1.ToString());
            try
            {
                empleado1.Sueldo = 9999;
                
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.WriteLine(empleado1.ToString());


            Console.ReadLine();
            //la segunda vez que intente ingresar un empleado con mas de 9500 no tine que avisar nada
        }
    }
}
