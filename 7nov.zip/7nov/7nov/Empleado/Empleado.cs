﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7nov
{
    //debe ser publico para que el evento y el delegado lo vean
    //modificador delegate returno nombre(parametro) 
    public delegate void DelEmpl();
    public delegate void DelConEmpl(Empleado empl);
    public delegate void DelConSueldo(Empleado empl,double sueldo);
    public delegate void DelConSueldo2(object empl, EmpleadoEventArgs sueldo);

    public class EmpleadoEventArgs : EventArgs
    {
        public double _sueldo;
    }

    public class Empleado
    {
        //nombre
        private string _nombre;

        public string Nombre
        {
            get { return this._nombre; }
            set { this._nombre = value; }
        }
        //apellido
        private string _apellido;

        public string Apellido
        {   
            get { return this._apellido; }
            set { this._apellido = value; }
        }
        //sueldo
        private double _sueldo;

        public double Sueldo
        {
            get { return this._sueldo; }
            set 
            {
                if (value > 0 && value <=9500)
                {
                    this._sueldo = value;
                }
                else
                {
                    if (value > 9500)
                    {
                        //lanza evento
                        EmpleadoEventArgs EventArgs = new EmpleadoEventArgs();
                        EventArgs._sueldo = value;

                        this.LimiteSueldo();
                        //this.LimiteSueldoEmpleado(this);
                        this.LimiteSueldoEmpleadoYSueldo(this, value);
                        this.LimiteSueldoEmpleadoYSueldo2(this, EventArgs);
                    }
                    else
                    {
                        throw new Exception("Sueldo invalido\n");
                    }
                }
            }
        }
        public Empleado()
        { 

        }

        public Empleado(string nombre, string apellido, double sueldo)
            :this()
        {
            this.Nombre = nombre;
            this.Apellido = apellido;
            this.Sueldo = sueldo;
        }


        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(this.Nombre + " " + this.Apellido + " " + this.Sueldo.ToString());
            return sb.ToString();
        }
        // evento para el delegado

        //nombrear al evento
        public event DelEmpl LimiteSueldo;
        public event DelConEmpl LimiteSueldoEmpleado;
        public event DelConSueldo LimiteSueldoEmpleadoYSueldo;
        public event DelConSueldo2 LimiteSueldoEmpleadoYSueldo2;
                    
    }
}
