﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form3 : Form
    {
        public static void ManejadorGenerico(Object obj, EventArgs events)
        {
                      
            
            MessageBox.Show("Estoy en el manejador generico");

            MessageBox.Show("Soy " + obj.GetType().Name);

            if (obj is TextBox)
            {

                ((TextBox)obj).BackColor = Color.Black;
                ((TextBox)obj).ForeColor = Color.White;
                ((TextBox)obj).Font = new Font("Tahoma", 18);
            }
            else
            {
                if (obj is Label)
                {
                    ((Label)obj).FlatStyle = FlatStyle.Popup;
                    ((Label)obj).BorderStyle = BorderStyle.Fixed3D;
                }
                else
                {
                    if (obj is Button)
                    {
                        ((Button)obj).Location = new Point(0, 0);                     
                    }
                }
            }
        }

        public Form3()
        {
            InitializeComponent();

            foreach (Control i in this.Controls)
            {
                i.Click += new EventHandler(ManejadorGenerico);
            }


            //this.label1.Click += new EventHandler(ManejadorGenerico);
            //this.button1.Click += new EventHandler(ManejadorGenerico);
            //this.textBox1.Click += new EventHandler(ManejadorGenerico);

        }
        
        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }
    }
}
