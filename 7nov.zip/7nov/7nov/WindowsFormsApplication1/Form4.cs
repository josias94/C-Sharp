﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form4 : Form
    {
        public void ManejadorGenerico(Object obj, EventArgs events)
        {
            if (obj == this.button1)
            {
                MessageBox.Show("Soy " + this.button1.Name);
                this.button1.Click -= new EventHandler(ManejadorGenerico);
                this.button2.Click += new EventHandler(ManejadorGenerico);
                this.label1.Text = "Manejador en boton 2";
            }
            else
            {
                if (obj == this.button2)
                {
                    MessageBox.Show("Soy " + this.button2.Name);
                    this.button2.Click -= new EventHandler(ManejadorGenerico);
                    this.button3.Click += new EventHandler(ManejadorGenerico);
                    this.label1.Text = "Manejador en boton 3";
                }
                else
                {
                    if (obj == this.button3)
                    {
                        MessageBox.Show("Soy " + this.button3.Name);
                        this.button3.Click -= new EventHandler(ManejadorGenerico);
                        this.button4.Click += new EventHandler(ManejadorGenerico);
                        this.label1.Text = "Manejador en boton 4";
                    }
                    else
                    {
                        if (obj == this.button4)
                        {
                            MessageBox.Show("Soy " + this.button4.Name);
                            this.button4.Click -= new EventHandler(ManejadorGenerico);
                            this.button1.Click += new EventHandler(ManejadorGenerico);
                            this.label1.Text = "Manejador en boton 1";
                        }
                    }
                }
            }
        }
        public Form4()
        {
            InitializeComponent();        
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            this.button1.Click += new EventHandler(ManejadorGenerico);
            this.label1.Text = "Manejador en boton 1";
            
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
                      
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
             
        }

        private void button4_Click(object sender, EventArgs e)
        {
             
        }

        
    }
}
