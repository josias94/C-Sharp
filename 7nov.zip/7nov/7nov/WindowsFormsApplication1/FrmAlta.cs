﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using _7nov;

namespace WindowsFormsApplication1
{
    public partial class FrmAlta : Form
    {
        public static void ManejadorConEmpleadoYSueldo(Empleado empl, double sueldo)
        {
            MessageBox.Show("Empleado que quiso subirse el sueldo:\n");
            MessageBox.Show(empl.ToString());
            MessageBox.Show("Y el sueldo que intento poner fue" + sueldo.ToString());
        }

        public static void Manejador()
        {
            MessageBox.Show("Estoy en el manejador de limite sueldo\n");
        }
  
        public static void ManejadorConEmpleado(Empleado empl)
        {
            MessageBox.Show("Empleado que quiso subirse el sueldo:\n");
            MessageBox.Show(empl.ToString());
        }

        Empleado empl;
        public FrmAlta()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.empl = new Empleado();

            this.empl.LimiteSueldoEmpleadoYSueldo += new DelConSueldo(ManejadorConEmpleadoYSueldo);

            empl.LimiteSueldo += new DelEmpl(Manejador);
            //manejador de instancia
            

            empl.LimiteSueldoEmpleado += new DelConEmpl(ManejadorConEmpleado);

            







            this.empl.Apellido = this.txbApellido.Text;
            this.empl.Nombre = this.tbxNombre.Text;
            this.empl.Sueldo = double.Parse(this.txbSueldo.Text);

        }
    }
}
