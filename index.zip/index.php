<h1>
Hola Mundo
</h1>
<?php
$usuario ="josias<br>";// $_GET['nombre'];
var_dump($usuario);

//$apellido = $_GET['apellido'];
echo "el nombre del usuario es  ".$usuario;//"<br>el apellido del usuario es  ".$apellido;

?>