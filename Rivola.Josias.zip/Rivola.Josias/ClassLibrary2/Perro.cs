﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2
{
    public class Perro:Mascota
    {
        #region Atributos
        private int _edad;
        private bool _esAlfa;
        #endregion
        #region constructor
        public Perro(string nombre, string raza)
            :this(nombre,raza,0,false)
        {

        }

        public Perro(string nombre, string raza,int edad,bool esAlfa)
            :base(nombre,raza)
        {
            this._edad = edad;
            this._esAlfa = esAlfa;
        }
        #endregion

        #region Metodos
        protected override string Ficha()
        {
            return this.DatosCompletos();
        }

        protected override string DatosCompletos()
        {
            StringBuilder retorno = new StringBuilder();
            retorno.Append(base.DatosCompletos() + ", ");
            if (this._esAlfa)
            {
                retorno.Append("alfa de la manada, ");
            }
            retorno.Append("edad " + ((int)this).ToString());
            return retorno.ToString();
        }
        #endregion

        #region Sobrecarga
        public static bool operator ==(Perro uno, Perro dos)
        {
            return uno.Nombre == dos.Nombre && uno.Raza == dos.Raza&&uno._edad==dos._edad;
        }

        public static bool operator !=(Perro uno, Perro dos)
        {
            return !(uno == dos);
        }

        public static explicit operator int(Perro uno)
        {
            return uno._edad;
        }


        public override bool Equals(object obj)
        {
            return obj is Perro;
        }

        public override string ToString()
        {
            return this.Ficha();
        }
        #endregion
    }
}
