﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2
{
    public class Gato:Mascota
    {
        #region constructores
        public Gato(string nombre, string raza)
            : base(nombre, raza)
        {

        }
        #endregion  

        #region Metodos
        protected override string Ficha()
        {
            return base.DatosCompletos();
        }
 
        #endregion

        #region sobrecarga
        public static bool operator ==(Gato uno, Gato dos)
        {
            return uno.Nombre == dos.Nombre && uno.Raza == dos.Raza;
        }

        public static bool operator !=(Gato uno, Gato dos)
        {
            return !(uno == dos);
        }

        public override bool Equals(object obj)
        {
            return obj is Gato;
        }

        public override string ToString()
        {
            return this.Ficha();
        }    
        #endregion
    }
}
