﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2
{
    public class Grupo
    {
        private List<Mascota> _manada;
        private string _nombre;
        private static EtipoManada _tipo;

        #region constructores
        static Grupo()
        {
            Grupo._tipo = EtipoManada.Unica;               
        }
        private Grupo()
        {
            this._manada = new List<Mascota>();
        }
        public Grupo(string nombre):this()
        {
            this._nombre = nombre;
        }
        public Grupo(string nombre, EtipoManada tipo):this(nombre)
        {
            Grupo._tipo = tipo;
        }
        #endregion

        #region Propiedades
        public EtipoManada Tipo { set { Grupo._tipo = value; } }

        #endregion

        #region Metodos
        public static implicit operator string(Grupo g)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Grupo:"+g._nombre+" - tipo: "+ Grupo._tipo.ToString());
            sb.AppendLine("Integrantes(" + g._manada.Count.ToString() + ")");
            for (int i = 0; i < g._manada.Count; i++)
            {
                if (g._manada[i] is Perro)
                {
                    sb.AppendLine(((Perro)g._manada[i]).ToString());
                }
                else
                {
                    if (g._manada[i] is Gato)
                    {
                        sb.AppendLine(((Gato)g._manada[i]).ToString());
                    }
                }
            }
            return sb.ToString();
        }
        #endregion

        public static bool operator ==(Grupo g, Mascota m)
        {
            bool igual = false;
            for (int i = 0; i < g._manada.Count; i++)
            {
                if (g._manada[i] == m)
                {
                    igual = true;
                    break;
                }
            }
            return igual;
        }

        public static bool operator !=(Grupo g, Mascota m)
        {
            return !(g == m);
        }

        public static Grupo operator +(Grupo g, Mascota m)
        {
            Grupo retorno = g;
            if (retorno != m)
            {
                retorno._manada.Add(m);
            }
            else
            {
                Console.Write("Ya esta el "+m.ToString()+" en el grupo.\n");                
            }
            return retorno;
        }

        public static Grupo operator -(Grupo g, Mascota m)
        {
            if (g == m)
            {
                g._manada.Remove(m);
            }
            else
            {
                Console.WriteLine("No esta el " + m.ToString() + " en el grupo.");
            }
            return g;
        }
    }
}
