﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clase06.entidades;


namespace Clase_6
{
    class Program
    {
        static void Main(string[] args)
        {
            /* tipo [] nombre;         
            int[] vec;// en este momento esta inicializado en null
            vec = new int[3];//ahora si estan los elemientos inicializados en 0
            int [,] matriz = new int[2, 3];
            tipo [,] otro nombre = new tipo[2,3];
            matriz
            
             
            vec[0] = 32;
            vec[1] = 5;
            vec[2] = 7;

            foreach(tipo i in coleccion)
             *con el foreach no se puede modificar la coleccion
             *no se puede eliminar, agregar o modificar
            si se puede modificar pero despues romper
             *porque si el foreach ve una modificacion va a fallar
             
            foreach (int i in vec)
            {
                Console.Write(i);
                //i = 0;
                //break;
            }
            */
            Paleta paletaUno = 5;


            Tempera temperaUno = new Tempera(ConsoleColor.DarkRed, "Filgo", 11);
            Tempera temperaDos = new Tempera(ConsoleColor.Cyan, "Virgo", 99);
            Tempera temperaTres = new Tempera(ConsoleColor.DarkRed, "Filgo", 13);

            Console.WriteLine(Tempera.Mostrar(temperaUno));
            Console.WriteLine(Tempera.Mostrar(temperaDos));
            Console.WriteLine(Tempera.Mostrar(temperaTres));

            temperaDos += -9;
            Console.WriteLine(Tempera.Mostrar(temperaDos));

            if (temperaUno == temperaTres)
            {
                Console.WriteLine("son iguales");
            }




            Console.WriteLine(Paleta.Mostrar(paletaUno));












            Console.Read();
        }
    }
}
