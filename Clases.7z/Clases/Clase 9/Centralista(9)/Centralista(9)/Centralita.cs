﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Centralista_9_
{
    public class Centralita
    {
        #region Atributos
        private List<Llamada> _listaLlamadas = new List<Llamada>();
        protected string _razonSocial;
        #endregion

        #region Propiedades
        public float GananciaPorLocal { get{ return CalcularGanancia(TipoLlamada.Local);} }
        public float GananciaPorProvincial { get { return CalcularGanancia(TipoLlamada.Provincial); } }
        public float GananciaTotal { get { return CalcularGanancia(TipoLlamada.Todas); } }
        public List<Llamada> Llamadas { get { return this._listaLlamadas; } }
        #endregion

        #region Constructores
        public Centralita(): this("")
        {

        }

        public Centralita(string nombreEmpresa)
        {
            this._razonSocial = nombreEmpresa;
        }
        #endregion

        #region Metodos instancia

        private float CalcularGanancia(TipoLlamada tipo)
        {
            float gananciaLocal=0;
            float gananciaProvincial = 0;
            float retorno = 0;

            foreach (Llamada i in this._listaLlamadas)
            {
                if (i is Local)
                {
                    gananciaLocal += ((Local)i).CostoLlamada;
                }
                else
                {
                    if (i is Provincial)
                    {
                        gananciaProvincial += ((Provincial)i).CostoLlamada;
                    }
                }         
            }
            switch (tipo)
            {
                case TipoLlamada.Local:
                    retorno = gananciaLocal;
                    break;
                case TipoLlamada.Provincial:
                    retorno = gananciaProvincial;
                    break;
                case TipoLlamada.Todas:
                    retorno = gananciaProvincial + gananciaLocal;
                    break;
            }
            return retorno;
        }

        //public string Mostrar()
        //{
        //    StringBuilder mensaje = new StringBuilder();

            
        //    mensaje.Append();
        //    mensaje.Append("Franja horaria: ");
        //    mensaje.AppendLine(this._franjaHoraria.ToString());
        //    mensaje.Append("Costo: ");
        //    mensaje.AppendLine(this.CostoLlamada.ToString());
        //    return mensaje.ToString();
        //}
        #endregion
    }
}
//public int OrdenarPorDuracion(Llamada uno, Llamada dos)
//        {
//            int retorno = 0;
//            if (uno.Duracion > dos.Duracion)
//            {
//                retorno = 1;
//            }
//            else
//            {
//                if (uno.Duracion < dos.Duracion)
//                {
//                    retorno = -1;
//                }
//            }
//            return retorno;
//        }