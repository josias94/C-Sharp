﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase8
{
    public class Tempera
    {
        private ConsoleColor _color;
        private string _marca;
        private int _cantidad;


        /// <summary>
        /// Constructor por defecto
        /// </summary>
        public Tempera()
        {
            this._marca = "Sin marca";
            this._color = ConsoleColor.Black;
            this._cantidad = 0;
        }

        /// <summary>
        /// Constructor parametrisado
        /// </summary>
        /// <param name="color">Color que sera inicializado</param>
        /// <param name="marca">Marca que sera inicializada</param>
        /// <param name="cantidad">Cantidad que sera inicializada</param>
        public Tempera(ConsoleColor color, string marca, int cantidad)
        {
            this._marca = marca;
            this._color = color;
            this._cantidad = cantidad;
        }

        /// <summary>
        /// retorna un string con los datos de los atributos
        /// </summary>
        /// <returns>string</returns>
        private string Mostrar()
        {
            return ("Marca: " + this._marca + " \nColor: " + this._color + " \nCantidad: " + this._cantidad + " \n");
        }

        /// <summary>
        /// invoca al metodo mostrar
        /// </summary>
        /// <param name="tempera">Tempera que sera mostrada</param>
        /// <returns></returns>
        public static string Mostrar(Tempera tempera)
        {
            return tempera.Mostrar();
        }

        //sobrecarga de operadores
        /// <summary>
        /// Compara dos Temperas por el color y la marca
        /// </summary>
        /// <param name="temperaUno">Tempera que sera verificada</param>
        /// <param name="temperaDos">Tempera que sera verificada</param>
        /// <returns>True si son iguales, false si son distintas</returns>
        public static bool operator ==(Tempera temperaUno, Tempera temperaDos)
        {     
            return temperaUno._color==temperaDos._color&&temperaUno._marca==temperaDos._marca;
        }

        //sobrecarga de operadores
        /// <summary>
        /// Compara dos Temperas por el color y la marca
        /// </summary>
        /// <param name="temperaUno">Tempera que sera verificada</param>
        /// <param name="temperaDos">Tempera que sera verificada</param>
        /// <returns>True si son distintas, false si son iguales</returns>
        public static bool operator !=(Tempera temperaUno, Tempera temperaDos)
        {
            return !(temperaUno._color == temperaDos._color && temperaUno._marca == temperaDos._marca);
        }

        /// <summary>
        /// suma una cantidad a las temperas mientras que  no sea mayor a 100 el varor resultante
        /// </summary>
        /// <param name="tempera">Tempera a la que se agregara </param>
        /// <param name="cantidad">Cantidad agregada</param>
        /// <returns>Tempera modificada</returns>
        public static Tempera operator +(Tempera tempera, double cantidad)
        {
            if (cantidad > 0 && tempera._cantidad+cantidad<=100)
            {
                tempera._cantidad = tempera._cantidad + (int) cantidad;
            }
            return tempera;
        }

        /// <summary>
        /// casteo implicito a int que da la cantidad de la tempera
        /// </summary>
        /// <param name="tempera">Tempera que sera casteada</param>
        /// <returns>Int cantidad</returns>
        public static implicit operator int(Tempera tempera)
        {
            return tempera._cantidad;
        }

        

        public string Marca
        {
            get { return this._marca; }
        }


        public ConsoleColor Color
        {
            get { return this._color; }
        }


        
    }
}
