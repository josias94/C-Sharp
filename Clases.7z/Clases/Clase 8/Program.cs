﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clase8;
namespace Clase_8
{
    class Program
    {
        static void Main(string[] args)
        {
            Paleta paleta = 5;
            Tempera tempera = new Tempera(ConsoleColor.Blue, "filgo", 10);
            paleta[0] = tempera;


            Console.WriteLine(Tempera.Mostrar( paleta[0]));
            Console.Read();
        }
    }
}
