﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clase8;
namespace Clase_8
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            Paleta paleta = 5;
            Tempera tempera1 = new Tempera(ConsoleColor.Blue, "filgo", 10);
            Tempera tempera2 = new Tempera(ConsoleColor.Blue, "filgo", 10);
            paleta[0] = tempera1;

            numero=Tempera.CompararCantidad(tempera1, tempera2);
            Console.WriteLine(numero);
            //Console.WriteLine(Tempera.Mostrar( paleta[0]));
            Console.Read();
        }
    }
}
