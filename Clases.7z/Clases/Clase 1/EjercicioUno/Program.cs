﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioUno
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            int elNumeroMenor=0;
            int elNumeroMayor=0;
          
            int contador=0;

            //for(contador=0; contador<5;contador++)

            while(contador <5)
            {
                contador++;
                Console.Write("Ingrese numero");
                while (!int.TryParse(Console.ReadLine(), out numero))
                {
                    Console.Write("Error, Reingrese numero");
                }
                if (contador == 1)
                {
                    elNumeroMenor = numero;
                    elNumeroMayor = numero;
                }
                else
                {
                    if (elNumeroMayor < numero)
                    {
                        elNumeroMayor = numero;
                    }
                    else
                    {
                        if (elNumeroMenor > numero)
                        {
                            elNumeroMenor = numero;
                        }
                    }
                }
               
            }
        }
    }
}
