﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase06.entidades
{
    public class Paleta
    {
        private Tempera[] _colores;
        private int _cantMaximaColores;

        private Paleta():this(5)
        {
            //this._cantMaximaColores = 5;
            //this._colores = new Tempera[this._cantMaximaColores];
        }

        private Paleta(int cantidad)
        {
            this._cantMaximaColores = cantidad;
            this._colores = new Tempera[this._cantMaximaColores];
        }

        public static implicit operator Paleta(int cantidad)
        {
            return new Paleta(cantidad);
        }


        private string Mostrar()
        {
            string mensaje="Paleta:\nCant max colores: "+this._cantMaximaColores+"\n";
            foreach (int i in this._colores)
            {
                mensaje+=Tempera.Mostrar(this._colores[i]);
                
            }
            return mensaje;   
        }
        //cant maxima paletas y las temperas
        public static string Mostrar(Paleta paleta)
        {
            return paleta.Mostrar();
        }
    }
}
