﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase06.entidades
{
    public class Paleta
    {
        private Tempera[] _colores;
        private int _cantMaximaColores;

        private Paleta(): this(5)
        {
            //this._cantMaximaColores = 5;
            //this._colores = new Tempera[this._cantMaximaColores];
        }

        private Paleta(int cantidad)
        {
            this._cantMaximaColores = cantidad;
            this._colores = new Tempera[this._cantMaximaColores];
        }

        public static implicit operator Paleta(int cantidad)
        {
            return new Paleta(cantidad);
        }


        private string Mostrar()
        {
            string mensaje = "Paleta: \nCant max colores: " + this._cantMaximaColores + " \n";

            for (int i = 0; i < this._cantMaximaColores; i++)
            {
                if (this._colores.GetValue(i) != null)
                {
                    mensaje += Tempera.Mostrar(this._colores[i]);
                }
            }
            
            return mensaje+" \n";
        }
        //cant maxima paletas y las temperas
        public static string Mostrar(Paleta paleta)
        {
            return paleta.Mostrar();
        }

        public static bool operator ==(Paleta paleta, Tempera tempera)
        {
            bool igual = false;
            for (int i = 0; i < paleta._cantMaximaColores; i++)
            {
                if (paleta._colores.GetValue(i) != null)
                {
                    if (paleta._colores[i] == tempera)
                    {
                        igual = true;
                        break;
                    }
                }
            }
            return igual;
        }

        public static bool operator !=(Paleta paleta, Tempera tempera)
        {
            return !(paleta == tempera);
        }


        public static Paleta operator +(Paleta paleta, Tempera tempera)
        {
            if (paleta != tempera)
            {
                if(paleta.ObtenerIndice() != -1)
                {
                     paleta._colores[paleta.ObtenerIndice()] = tempera;
                }
            }
            else
            {//el color esta en la paleta
                for (int i = 0; i < paleta._cantMaximaColores; i++)
                {
                    if (paleta._colores[i] == tempera)//rojo =70, rojo 70
                    {
                        paleta._colores[i] += tempera;
                        break;
                    }
                }
                
            }
            return paleta;
        }

        public static Paleta operator -(Paleta paleta, Tempera tempera)
        {
            if (paleta == tempera)
            {
                for(int i=0;i<paleta._cantMaximaColores;i++)
                {
                    if (paleta._colores.GetValue(i) != null)
                    {
                        if (paleta._colores[i] == tempera)
                        {
                            paleta._colores[i] = null;
                            break;
                        }
                    }
                }
            }
            return paleta;
        }

        /*public static Paleta operator +(Paleta paleta, Tempera tempera)
        {

        }*/





        private int ObtenerIndice()
        {
            int lugar = -1;
            for (int i = 0; i < this._cantMaximaColores; i++)
            {
                if (this._colores.GetValue(i) == null)
                {
                    lugar = i;
                    break;
                }
            }
            return lugar;
        }
    }
}
