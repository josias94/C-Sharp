﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase06.entidades
{
    public class Tempera
    {
        private ConsoleColor _color;
        private string _marca;
        private int _cantidad;

        public Tempera()
        {
            this._marca = "Sin marca";
            this._color = ConsoleColor.Black;
            this._cantidad = 0;
        }

        public Tempera(ConsoleColor color, string marca, int cantidad)
        {
            this._marca = marca;
            this._color = color;
            this._cantidad = cantidad;
        }

        private string Mostrar()
        {
            return ("Marca: " + this._marca + " \nColor: " + this._color + " \nCantidad: " + this._cantidad + " \n");
        }

        public static string Mostrar(Tempera tempera)
        {
            return tempera.Mostrar();
        }

        //sobrecarga de operadores

        public static bool operator ==(Tempera temperaUno, Tempera temperaDos)
        {     
            return temperaUno._color==temperaDos._color&&temperaUno._marca==temperaDos._marca;
        }

        public static bool operator !=(Tempera temperaUno, Tempera temperaDos)
        {
            return !(temperaUno._color == temperaDos._color && temperaUno._marca == temperaDos._marca);
        }



        public static Tempera operator +(Tempera tempera, double cantidad)
        {
            if (cantidad > 0 && tempera._cantidad+cantidad<=100)
            {
                tempera._cantidad = tempera._cantidad + (int) cantidad;
            }
            return tempera;
        }

        public static implicit operator int(Tempera tempera)
        {
            return tempera._cantidad;
        }
 
    }
}
