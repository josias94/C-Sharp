﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Clase8;


namespace test_paleta_wf
{
    public partial class FrmPaleta : Form
    {
        private Paleta _paleta;

        public FrmPaleta()
        {
            InitializeComponent();
            this._paleta = 10;
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            
            //Tempera tempera1 = new Tempera(ConsoleColor.Red, "eeeee", 5);
            //Tempera tempera2 = new Tempera(ConsoleColor.Blue, "eeeee", 2);
            //Tempera tempera3 = new Tempera(ConsoleColor.Red, "ddddd", 4);
            //Tempera tempera4 = new Tempera(ConsoleColor.Red, "ccccc", 3);
            //Tempera tempera5 = new Tempera(ConsoleColor.Red, "aaaaa", 1);
            //this._paleta += tempera1;
            //this._paleta += tempera2;
            //this._paleta += tempera3;
            //this._paleta += tempera4;
            //this._paleta += tempera5;

            //lstColores.Items.Clear();
            //lstColores.Items.Add(Paleta.Mostrar(this._paleta));


            //se crea el formulario que pide la tempera
            FrmTempera frmTempera = new FrmTempera();
            //invoca el formulario y le da el enfoque
            frmTempera.ShowDialog();

            if(frmTempera.DialogResult==DialogResult.OK)
            {
                //agrego la tempera a la paleta
                this._paleta[this._paleta.ListTemperas.Count] = frmTempera.getTempera();
                
                lstColores.Items.Clear();
                //la muestro por la consola de paleta
                foreach (Tempera i in this._paleta.ListTemperas)
                {
                    lstColores.Items.Add(Tempera.Mostrar(i));
                }               
               // _paleta.GetTempera()
            }           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int index = this.lstColores.SelectedIndex;
            if (index != -1)
            {
                Tempera tempera =this._paleta.ListTemperas[index];
                FrmTempera frmTempera = new FrmTempera(tempera);
                frmTempera.ShowDialog();

                if (frmTempera.DialogResult == DialogResult.OK)
                {
                    this._paleta.ListTemperas.RemoveAt(index);

                    lstColores.Items.Clear();
                    foreach (Tempera i in this._paleta.ListTemperas)
                    {
                        lstColores.Items.Add(Tempera.Mostrar(i));
                    }
                }
            }         
        }

        private void lstColores_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void aZToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            this._paleta.ListTemperas.Sort(Tempera.CompararMarca);
            lstColores.Items.Clear();
            foreach (Tempera i in this._paleta.ListTemperas)
            {
                lstColores.Items.Add(Tempera.Mostrar(i));
            }
        }

        private void zAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this._paleta.ListTemperas.Sort(Tempera.CompararMarca);
            this._paleta.ListTemperas.Reverse();
            lstColores.Items.Clear();
            foreach (Tempera i in this._paleta.ListTemperas)
            {
                lstColores.Items.Add(Tempera.Mostrar(i));
            }
        }

        private void mayorAMenorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this._paleta.ListTemperas.Sort(Tempera.CompararCantidad);
            this._paleta.ListTemperas.Reverse();
            lstColores.Items.Clear();
            foreach (Tempera i in this._paleta.ListTemperas)
            {
                lstColores.Items.Add(Tempera.Mostrar(i));
            }
        }

        private void menorAMayorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this._paleta.ListTemperas.Sort(Tempera.CompararCantidad);    
            lstColores.Items.Clear();
            foreach (Tempera i in this._paleta.ListTemperas)
            {
                lstColores.Items.Add(Tempera.Mostrar(i));
            }
        }

        private void aZToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this._paleta.ListTemperas.Sort(Tempera.CompararColor);
            lstColores.Items.Clear();
            foreach (Tempera i in this._paleta.ListTemperas)
            {
                lstColores.Items.Add(Tempera.Mostrar(i));
            }
        } 
    }
}
