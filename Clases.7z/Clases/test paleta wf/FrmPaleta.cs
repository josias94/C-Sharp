﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Clase06.entidades;

namespace test_paleta_wf
{
    public partial class FrmPaleta : Form
    {
        private Paleta _paleta;

        public FrmPaleta()
        {
            InitializeComponent();
            this._paleta = 5;
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            //Tempera tempera = new Tempera(ConsoleColor.Red, "Filgo", 10);
            //this._paleta += tempera;
            //lstColores.Items.Clear();
            //lstColores.Items.Add(Paleta.Mostrar(this._paleta));
            FrmTempera frmTempera = new FrmTempera();
            frmTempera.ShowDialog();

            if(frmTempera.DialogResult==System.Windows.Forms.DialogResult.OK)
            frmTempera.getTempera();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Tempera tempera = new Tempera(ConsoleColor.Red, "Filgo", 10);
            this._paleta -= tempera;
            lstColores.Items.Clear();
            lstColores.Items.Add(Paleta.Mostrar(this._paleta));
        }

        

        
       
    }
}
