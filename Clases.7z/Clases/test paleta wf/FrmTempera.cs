﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Clase06.entidades;

namespace test_paleta_wf
{
    public partial class FrmTempera : Form
    {
        private Tempera _tempera;
        public FrmTempera()
        {
            InitializeComponent();
        }

        public Tempera getTempera()
        {
            return this._tempera;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string marca = this.textBox1.Text;
            ConsoleColor color =(ConsoleColor)Enum.Parse(typeof(ConsoleColor),this.textBox2.Text);
            int cantidad = (int)Enum.Parse(typeof(int), this.textBox3.Text);
            

            _tempera = new Tempera(color,marca,cantidad);//marca,color,cantidad


            this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }

    }
}
