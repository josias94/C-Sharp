﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using Entidades;

namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {
            ProveedorDeDatos pdd = new ProveedorDeDatos();
            DataTable t = pdd.ObtenerPersonasBd(true);

            List<Persona> listaPersonas = pdd.obtenerPersonasBD();

            for (int i = 0; i < listaPersonas.Count; i++) {
                Console.WriteLine(listaPersonas[i].ToString());
            }

            //Console.WriteLine(pdd.obtenerPersonaPorIDBD(2).ToString());


            /*if (pdd.obtenerPersonaPorIDBD(80) == null)
            {
                Console.WriteLine("El objeto efectivamente es nulo.");
            }*/

            Persona personita = new Persona(38999220, "Ezequiel", "Mahafud", 22);

            pdd.agregarPersonaBD(personita);

            listaPersonas = pdd.obtenerPersonasBD();

            for (int i = 0; i < listaPersonas.Count; i++)
            {
                Console.WriteLine(listaPersonas[i].ToString());
            }

            Console.Read();

            /*Persona personita = new Persona(39500000, "Luz", "Rubini", 20);

            pdd.agregarPersona(personita);
            pdd.modificarPersona(personita);
            pdd.eliminarPersona(personita);*/
        }
    }
}
