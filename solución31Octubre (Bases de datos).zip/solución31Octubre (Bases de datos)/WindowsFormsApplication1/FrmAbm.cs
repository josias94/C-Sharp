﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades; 

namespace WindowsFormsApplication1
{
    public partial class FrmAbm : Form
    {
        public Persona _persona;
        public FrmAbm()
        {
            InitializeComponent();
        }

        public FrmAbm(Persona p1):this()
        {
            this.tbApellido.Text = p1._apellido;
            this.tbName.Text = p1._nombre;
            this.tbEdad.Text = p1._edad.ToString();

        }

        public Persona Persona 
        {
            get
            {
                return this._persona;
            }

        }


        private void btnAceptar_Click(object sender, EventArgs e)
        {
            this._persona= new Persona(0,this.tbName.Text,this.tbApellido.Text,int.Parse(this.tbEdad.Text));
            this.DialogResult = DialogResult.OK;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
