﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        //public List<Persona> _lista;
        public DataTable _dataTable;
        public ProveedorDeDatos _proveedor;
        public Form1()
        {
            InitializeComponent();
            this._proveedor = new ProveedorDeDatos();
            //this._lista = this._proveedor.obtenerPersonasBD();  
            this._dataTable = this._proveedor.ObtenerPersonasBd(true);
            
        }    

        private void btAgregar_Click(object sender, EventArgs e)
        {
            FrmAbm abm = new FrmAbm();
            abm.ShowDialog();
            if (abm.DialogResult == DialogResult.OK)
            {
                DataRow f = this._dataTable.NewRow();
                f["nombre"] = abm.Persona._nombre;
                f["apellido"] = abm.Persona._apellido;
                f["edad"] = abm.Persona._edad;

                this._dataTable.Rows.Add(f);
            //    //this.ListBox.Items.Clear();
            //    this._proveedor.agregarPersonaBD(abm.Persona);
            //    //this._lista = this._proveedor.obtenerPersonasBD();
            //    this._dataTable = this._proveedor.ObtenerPersonasBd(true);

            //    //foreach (Persona p in this._lista)
            //    //{
            //    //    this.ListBox.Items.Add(p.ToString());
            //    //}
            }
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            this.dataGridView1.DataSource = this._dataTable;
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            
            //foreach (Persona p in this._lista)
            //{
            //    this.ListBox.Items.Add(p.ToString());
            //}
        }

        private void bnEliminar_Click(object sender, EventArgs e)
        {
            //int index = this.dataGridView1.se;
            //if (index >= 0)
            //{
                //FrmAbm abm = new FrmAbm(this._lista[index]);
                //abm.ShowDialog();
                //if (abm.DialogResult == DialogResult.OK)
                //{
                //    this.ListBox.Items.Clear();
                //    this._proveedor.eliminarPersonaBD(this._lista[index]);
                //    this._lista = this._proveedor.obtenerPersonasBD();
                //    foreach (Persona p in this._lista)
                //    {
                //        this.ListBox.Items.Add(p.ToString());
                //    }
                //}
            //}
        }

        private void ListBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnBackUp_Click(object sender, EventArgs e)
        {
            this._dataTable.WriteXmlSchema("esquema.xml");
            this._dataTable.WriteXml("datos.xml");
        }

        
    }
}
//el DataTable es auto serializable al xml asi que puedo convertirlo a xlm y llevar la base de datos en un archivo