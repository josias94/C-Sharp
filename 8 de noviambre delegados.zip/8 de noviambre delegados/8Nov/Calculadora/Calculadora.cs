﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//obje.inboke(3,8)
//d(3,8)



namespace Calculadora
{
    public delegate void Delegado(object objeto,EventArgs resultado);

    public class ResultadoEventArgs : EventArgs
    {
        public double numero;
    }
    public class Calculadora
    {
        private double numeroUno;
        private double numeroDos;

        public void Suma()
        {
            ResultadoEventArgs EventArgs = new ResultadoEventArgs();

            EventArgs.numero = this.numeroUno + this.numeroDos;

            this.DelSuma(this,EventArgs);            

        }
        public double Resta()
        {
            return this.numeroUno - this.numeroDos;
        }
        public double Multiplicacion()
        {
            return this.numeroUno * this.numeroDos;
        }
        public double Division()
        {
            return this.numeroUno / this.numeroDos;
        }
        public event Delegado DelSuma;
    }
    
}
