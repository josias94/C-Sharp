﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public void ManejadorCentral(Object objeto,EventArgs evento)
        {
            
            double numeroUno;

            foreach (Control i in this.Controls)
            {
                if (i is Panel)
                {
                    foreach (Control boton in this.panel1.Controls)
                    {
                        if (boton == objeto)
                        {
                            this.buttonSumar.Click += new EventHandler(ManejadorCentral);
                            this.buttonRestar.Click += new EventHandler(ManejadorCentral);
                            this.buttonMultiplicar.Click += new EventHandler(ManejadorCentral);
                            this.buttonDividir.Click += new EventHandler(ManejadorCentral);
                            break;
                        }
                    }
                }
                
            }

            if (objeto == this.buttonSumar || objeto == this.buttonRestar || objeto == this.buttonMultiplicar || objeto == this.buttonDividir)
            {
                //numeroUno = double.Parse(this.txtDisplay.Text);
                MessageBox.Show("Holaa");
            }
                       
            
            this.txtDisplay.Text += ((Button)objeto).Text;

            if (objeto == this.buttonIgual) 
            {

            }

        }


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (Control i in this.Controls)
            {
                if (i is Panel)
                {
                    foreach (Control boton in this.panel1.Controls)
                    {
                        boton.Click += new EventHandler(ManejadorCentral);
                    }
                }                                     
            }
        }

        

        

        

       

        
    }
}
