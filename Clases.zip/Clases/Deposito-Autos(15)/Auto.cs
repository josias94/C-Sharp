﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Deposito_Autos_15_
{
    public class Auto
    {
        
        #region Atributos
        private string _color;
        private string _marca;
        #endregion

        #region Constructores
        public Auto() 
        {

        }
        public Auto(string color,string marca):this()
        {           
            this._color = color;
            this._marca = marca;
        }
        #endregion

        #region Propiedades
        public string Color { get { return this._color; } }
        public string Marca { get { return this._marca; } }
        #endregion

        #region Sobrecarga
        public static bool operator ==(Auto uno, Auto dos)
        {
            return uno._marca == dos._marca && uno._color == dos._color;
        }

        public static bool operator !=(Auto uno, Auto dos)
        {
            return !(uno==dos);
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Marca: ");
            sb.Append(this._marca);
            sb.Append(" - Color: ");
            sb.AppendLine(this._color);
            return sb.ToString();
        }

        public override bool Equals(object obj)
        {   
            return obj is Auto && this == (Auto)obj;
        }
        #endregion
    }
}
