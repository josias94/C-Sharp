﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Deposito_Autos_15_
{
    public class Deposito<T> where T : new()
    {
        
        #region Atributos
        private int _capacidadMaxima;
        private List<T> _lista;
        #endregion

        #region Constructor
        public Deposito(int cantidad)
        {
            this._capacidadMaxima = cantidad;
            this._lista = new List<T>();
        }
        #endregion

        #region Metodos
        private int GetIndice(T a)
        {
            int index=-1;
            int i;
            for (i = 0; i < this._lista.Count;i++)
            {
                if (a.Equals(this._lista[i]))
                {
                    index = i;
                }
            }
            return index;
        }
        #endregion

        #region Sobrecarga
        public static bool operator +(Deposito<T> deposito, T a)
        {
            bool retorno=false;
            if (deposito._capacidadMaxima > deposito._lista.Count)
            {
                deposito._lista.Add(a);
                retorno = true;
            }
            return retorno;
        }

        public static bool operator -(Deposito<T> deposito, T a)
        {
            bool retorno = false;
            if (deposito.GetIndice(a) != -1)
            {
                deposito._lista.RemoveAt(deposito.GetIndice(a));
                retorno = true;
            }
            return retorno;
        }

        public bool Agregar(T a)
        {
            return this + a;
        }
        public bool Remover(T a)
        {
            return this - a;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Capacidad maxima:");
            sb.AppendLine(this._capacidadMaxima.ToString());
            sb.Append("Listadode ");
            sb.AppendLine(typeof(T).Name);
            foreach (T a in this._lista)
            {
                sb.Append(a.ToString());
            }
            return sb.ToString();
        }
        #endregion
    }
}
