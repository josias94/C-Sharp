﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Deposito_Autos_15_
{
    public class DepositoDeAutos
    {
        #region Atributos
        private int _cantidadMaxima;
        public List<Auto> _lista;
        #endregion

        #region Contructores
        public DepositoDeAutos(int cantidad)
        {
            this._cantidadMaxima = cantidad;
            this._lista = new List<Auto>();
        }
        #endregion

        #region Sobrecarga
        public static bool operator +(DepositoDeAutos deposito, Auto auto)
        {
            bool retorno=false;
            if (deposito._cantidadMaxima > deposito._lista.Count)
            {
                deposito._lista.Add(auto);
                retorno = true;
            }
            return retorno;
        }

        public static bool operator -(DepositoDeAutos deposito, Auto auto)
        {
            bool retorno = false;
            if (deposito.GetIndice(auto) != -1)
            {
                deposito._lista.RemoveAt(deposito.GetIndice(auto));
                retorno = true;
            }
            return retorno;
        }

        private int GetIndice(Auto auto)
        {
            int index=-1;
            int i;
            for (i = 0; i < this._lista.Count;i++)
            {
                if (this._lista[i] == auto)
                {
                    index = i;
                }
            }

            return index;
        }
        public bool Agregar(Auto auto)
        {
            return this + auto;
        }
        public bool Remover(Auto auto)
        {
            return this - auto;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Capacidad:");
            sb.AppendLine(this._cantidadMaxima.ToString());
            sb.AppendLine("Autos:");
            foreach (Auto a in this._lista)
            {
                sb.AppendLine(a.ToString());
            }
            return sb.ToString();
        }
        #endregion
    }
}
