﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Deposito_Autos_15_
{
    public class Cocina
    {
        #region Atributos
        private int _codigo;
        private bool _esIndustrial;
        private double _precio;
        #endregion

        #region Propiedades
        public int Codigo { get { return this._codigo; } }
        public bool EsIndustrial { get { return this._esIndustrial; } }
        public double Precio { get { return this._precio; } }
        #endregion    
        #region Constructores
        public Cocina()
        {

        }
        public Cocina(int codigo, double precio, bool esindustrial):this()
        {
            this._codigo = codigo;
            this._esIndustrial = esindustrial;
            this._precio = precio;
        }
        #endregion

        #region Sobrecarga
        public static bool operator==(Cocina uno, Cocina dos)
        {
            return uno._codigo == dos._codigo;
        }

        public static bool operator!=(Cocina uno, Cocina dos)
        {
            return !(uno == dos);
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Codigo: ");
            sb.Append(this._codigo.ToString());
            sb.Append(" - Precio: ");
            sb.Append(this._precio.ToString());
            sb.Append(" - Es industrial? ");
            sb.AppendLine(this._esIndustrial.ToString());
            return sb.ToString();
        }

        public override bool Equals(object obj)
        {
            return obj is Cocina && this == (Cocina)obj;
        }
        #endregion

    }
}
