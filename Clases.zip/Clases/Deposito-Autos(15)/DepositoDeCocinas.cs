﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Deposito_Autos_15_
{
    public class DepositoDeCocinas
    {
        #region Atributos
        private int _capacidadMaxima;
        private List<Cocina> _lista;
        #endregion

        #region Constructor
        public DepositoDeCocinas(int cantidad)
        {
            this._capacidadMaxima = cantidad;
            this._lista = new List<Cocina>();
        }
        #endregion

        #region Metodos
        private int GetIndice(Cocina cocina)
        {
            int index=-1;
            int i;
            for (i = 0; i < this._lista.Count;i++)
            {
                if (this._lista[i] == cocina)
                {
                    index = i;
                }
            }
            return index;
        }
        #endregion

        #region Sobrecarga
        public static bool operator +(DepositoDeCocinas deposito, Cocina cocina)
        {
            bool retorno=false;
            if (deposito._capacidadMaxima > deposito._lista.Count)
            {
                deposito._lista.Add(cocina);
                retorno = true;
            }
            return retorno;
        }

        public static bool operator -(DepositoDeCocinas deposito, Cocina cocina)
        {
            bool retorno = false;
            if (deposito.GetIndice(cocina) != -1)
            {
                deposito._lista.RemoveAt(deposito.GetIndice(cocina));
                retorno = true;
            }
            return retorno;
        }

        public bool Agregar(Cocina cocina)
        {
            return this + cocina;
        }
        public bool Remover(Cocina cocina)
        {
            return this - cocina;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Capacidad maxima:");
            sb.AppendLine(this._capacidadMaxima.ToString());
            sb.AppendLine("listado de cocinas:");
            foreach (Cocina c in this._lista)
            {
                sb.Append(c.ToString());
            }
            return sb.ToString();
        }
        #endregion
    }
}
