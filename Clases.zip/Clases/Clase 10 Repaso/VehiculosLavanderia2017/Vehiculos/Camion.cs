﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehiculos
{
    class Camion:Vehiculos
    {
        #region Atributos
        protected float _tara;
        #endregion

        #region Constructores
        public Camion(string patente,byte cantRuedas,EMarca marca,float tara)
            :base(patente,cantRuedas,marca)
        {
            this._tara = tara;
        }
        public Camion(Vehiculos vehiculo,float tara)
            :this(vehiculo.Patente,vehiculo.CantRuedas,vehiculo.Marca,tara)
        {
            
        }
        #endregion

        #region Metodos
        public override string ToString()
        {
            StringBuilder mensaje = new StringBuilder();
            mensaje.AppendLine(base.ToString());
            mensaje.Append("Tara: ");
            mensaje.AppendLine(this._tara.ToString());
            return mensaje.ToString();
        }
        #endregion
    }
}
