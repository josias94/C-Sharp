﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehiculos
{
    class Moto:Vehiculos
    {
        #region Atributos
        protected float _cilindrada;
        #endregion

        #region Constructores
        //Moto: marca, patente, cilindrada y cantidad de ruedas
        public Moto(EMarca marca, string patente, float cilindrada, byte cantRuedas)
            :base(patente,cantRuedas,marca)
        {
            this._cilindrada = cilindrada;
        }
        #endregion

        #region Metodos
        public override string ToString()
        {
            StringBuilder mensaje = new StringBuilder();
            mensaje.AppendLine(base.ToString());
            mensaje.Append("Cilindrada: ");
            mensaje.AppendLine(this._cilindrada.ToString());
            return mensaje.ToString();
        }
        #endregion
    }
}
