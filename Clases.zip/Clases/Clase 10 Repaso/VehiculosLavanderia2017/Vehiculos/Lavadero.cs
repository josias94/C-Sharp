﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehiculos
{
    class Lavadero
    {
        #region Atributos
        List<Vehiculos> _vehiculos;
        private static float _precioAuto;
        private static float _precioCamion;
        private static float _precioMoto;
        private string _razonSocial;
        #endregion

        #region Propiedades
        public string Lavaderos 
        { 
            get
            {
                StringBuilder mensaje=new StringBuilder();
                mensaje.Append("Razon social: ");
                mensaje.AppendLine(this._razonSocial.ToString());
                mensaje.Append("Precio auto: ");
                mensaje.AppendLine(Lavadero._precioAuto.ToString());
                mensaje.Append("Precio Camion: ");
                mensaje.AppendLine(Lavadero._precioCamion.ToString());
                mensaje.Append("Precio Moto: ");
                mensaje.AppendLine(Lavadero._precioMoto.ToString());

                foreach(Vehiculos i in this.Vehiculos)
                {
                    mensaje.AppendLine(i.ToString());
                }
                return mensaje.ToString();
             
            } 
        }
        public List<Vehiculos> Vehiculos
        { 
            get
            {
               return this._vehiculos; 
            }      
        }
        
        #endregion

        #region Constructores
        private static Lavadero()
        {
            Random precio = new Random();           
            Lavadero._precioAuto = precio.Next(150, 565);
            do
            {
                Lavadero._precioCamion = precio.Next(150, 565);
            }
            while(Lavadero._precioCamion==Lavadero._precioAuto);          
            do
            {
                Lavadero._precioMoto = precio.Next(150, 565);
            }
            while (Lavadero._precioMoto == Lavadero._precioAuto || Lavadero._precioMoto==Lavadero._precioCamion);            
        }

        private Lavadero()
        {
            this._vehiculos = new List<Vehiculos>();
        }

        public Lavadero(string razonSocial):this()
        {
            this._razonSocial=razonSocial;           
        }
        #endregion

        #region Metodos
        public double MostrarTotalFacturado(EVehiculo tipo)
        {
            double acumulador = 0;
            double acumuladorAuto = 0;
            double acumuladorCamion = 0;
            double acumuladorMoto = 0;
            foreach (Vehiculos i in this.Vehiculos)
            {
                if (i is Auto)
                {
                    acumuladorAuto = Lavadero._precioAuto;
                }
                else
                {
                    if (i is Camion)
                    {
                        acumuladorCamion = Lavadero._precioCamion;
                    }
                    else
                    {
                        if (i is Moto)
                        {
                            acumuladorMoto = Lavadero._precioMoto;
                        }
                    }
                }
            }
            switch (tipo)   
            {
                case EVehiculo.Auto:
                    acumulador = acumuladorAuto;
                    break;
                case EVehiculo.Camion:
                    acumulador = acumuladorCamion;
                    break;
                case EVehiculo.Moto:
                    acumulador = acumuladorMoto;
                    break;
                default:
                    break;
            }         
            return acumulador;
        }

        public double MostrarTotalFacturado()
        {
            return MostrarTotalFacturado(EVehiculo.Auto) + MostrarTotalFacturado(EVehiculo.Camion) + MostrarTotalFacturado(EVehiculo.Moto);
        }
        #endregion

        #region Sobrecarga de operadores
        public static bool operator ==(Lavadero lavadero, Vehiculos vehiculo)
        {
            bool retorno = false;
            foreach (Vehiculos i in lavadero.Vehiculos)
            {
                if (i == vehiculo)
                {
                    retorno = true;
                    break;
                }
            }
            return retorno;
        }

        public static int operator ==(Vehiculos vehiculo, Lavadero lavadero)
        {
            int retorno = -1;
            int i;
            for (i = 0; i < lavadero.Vehiculos.Count; i++)
            {
                if (lavadero.Vehiculos[i] == vehiculo)
                {
                    retorno = i;
                }
            }
            return retorno;
        }
        #endregion
    }
}
