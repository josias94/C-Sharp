﻿public enum EMarca
{
    Honda, Ford, Zanella, Scania, Iveco, Fiat
}
enum EVehiculo
{
    Auto, Camion, Moto
}