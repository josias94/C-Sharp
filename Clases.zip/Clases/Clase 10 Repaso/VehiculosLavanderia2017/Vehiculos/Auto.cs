﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehiculos
{
    class Auto:Vehiculos
    {
        #region Atributos
        protected int _cantAsientos;
        #endregion

        #region Constructores
        public Auto(string patente,EMarca marca,int cantAsientos)
            :base(patente,4,marca)
        {
            this._cantAsientos = cantAsientos;
        }
        #endregion

        #region Metodos
        public override string ToString()
        {
            StringBuilder mensaje = new StringBuilder();
            mensaje.AppendLine(base.ToString());
            mensaje.Append("Cantidad de asientos: ");
            mensaje.AppendLine(this._cantAsientos.ToString());
            return mensaje.ToString();
        }
        #endregion

    }
}
