﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehiculos
{
    public class Vehiculos
    {
        #region Atributos
        protected string _patente;
        protected byte _cantRuedas;
        protected EMarca _marca;
        #endregion

        #region Propiedades
        public string Patente { get { return this._patente; } }

        public byte CantRuedas 
        { 
            get
            { 
                return this._cantRuedas;
            } 
            set
            {
                this._cantRuedas = value;
            } 
        }

        public EMarca Marca { get { return this._marca; } }
        #endregion

        #region Constructores
        public Vehiculos(string patente, byte cantRuedas, EMarca marca)
        {
            this._patente = patente;
            this._cantRuedas = cantRuedas;
            this._marca=marca;
        }
        #endregion

        #region Metodos de instancia
        private string Mostrar()
        {
            StringBuilder mensaje = new StringBuilder();
            mensaje.Append("Patente: ");
            mensaje.AppendLine(Patente);
            mensaje.Append("Cantidad de ruedas: ");
            mensaje.AppendLine(this._cantRuedas.ToString());
            mensaje.Append("Marca: ");
            mensaje.AppendLine(Marca.ToString());
            return mensaje.ToString();
        }

        public override string ToString()
        {
            return this.Mostrar();
        }
        #endregion

        #region Sobrecarga de operadores
        public static bool operator ==(Vehiculos uno, Vehiculos dos)
        {
            return uno.Patente == dos.Patente && uno.Marca == dos.Marca;
        }

        public static bool operator !=(Vehiculos uno, Vehiculos dos)
        {
            return !(uno == dos);
        }
        #endregion

    }
}
