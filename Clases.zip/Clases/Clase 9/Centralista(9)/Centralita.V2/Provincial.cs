﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralistaV2
{
    public class Provincial:Llamada
    {
        #region Atributos
        protected Franja _franjaHoraria;
        #endregion

        #region Propiedades
        public override float CostoLlamada { get { return CalcularCosto(); } }
        #endregion

        #region Constructores
        public Provincial(Franja franja, Llamada unaLlamada)
            :this(unaLlamada.NroOrigen,franja,unaLlamada.Inicio,unaLlamada.NroDestino)
        {

        }

        public Provincial(string origen, Franja miFranja, DateTime ahora, string destino)
            : base(origen, destino, ahora)
        {
            this._franjaHoraria = miFranja;
        }
        #endregion

        #region Metodos instancia
        /// <summary>
        /// Retornará el valor de la llamada a partir de la duración y el costo de la misma.
        /// </summary>
        /// <returns></returns>
        public float CalcularCosto()
        {
            float costo=0;
            switch (this._franjaHoraria)
            {
                case Franja.Franja_1:
                    costo = base.Duracion * 0.99f;
                    break;
                case Franja.Franja_2:
                    costo = base.Duracion * 1.25f;
                    break;
                case Franja.Franja_3:
                    costo = base.Duracion * 0.66f;
                    break;
            }
            return costo;
        }

        protected override string Mostrar()
        {
            StringBuilder mensaje = new StringBuilder();
            mensaje.AppendLine(" Provincial");
            mensaje.Append(base.Mostrar());
            mensaje.Append(" Franja horaria: ");
            mensaje.AppendLine(this._franjaHoraria.ToString());
            mensaje.Append(" Costo: ");
            mensaje.AppendLine(this.CostoLlamada.ToString());
            return mensaje.ToString();
        }
        #endregion

        #region Sobrecarga de operadores
        public override string ToString()
        {
            return this.Mostrar();
        }

        public override bool Equals(object obj)
        {
            return obj is Provincial ;
        }
        #endregion
    }
}
