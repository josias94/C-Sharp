﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Centralista_9_
{
    public class Local:Llamada
    {
        #region Atributos
        protected float _costo;
        #endregion

        #region Propiedades
        public float CostoLlamada { get { return CalculaCosto(); } }
        #endregion

        #region Constructores
        public Local(Llamada unaLlamada, float costo)
            : this(unaLlamada.NroOrigen, unaLlamada.NroDestino, unaLlamada.Duracion, costo)
        {
            
        }

        public Local(string origen, string destino, float duracion, float costo)
            : base(origen, destino, duracion)
        {
            this._costo = costo;
        }
        //hay otra manera de hacerlo pero me da paja ahora
        #endregion

        #region Metodos instancia
        /// <summary>
        /// Retornará el valor de la llamada a partir de la duración y el costo de la misma.
        /// </summary>
        /// <returns></returns>
        private float CalculaCosto()
        {
            return this._costo * base.Duracion;
        }

        protected override string Mostrar()
        {
            StringBuilder mensaje = new StringBuilder();
            mensaje.AppendLine(" Local ");
            mensaje.Append(base.Mostrar());
            mensaje.Append(" Costo: ");
            mensaje.AppendLine(this.CostoLlamada.ToString());
            return mensaje.ToString();
        }
        #endregion

        #region Sobrecarga de operadores
        public override string ToString()
        {
            return this.Mostrar();
        }

        public override bool Equals(object obj)
        {
            return obj is Local;
        }
        #endregion      
    }
}
