﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Centralista_9_
{
    public class Centralita
    {
        #region Atributos
        private List<Llamada> _listaLlamadas = new List<Llamada>();
        protected string _razonSocial;
        #endregion

        #region Propiedades
        public float GananciaPorLocal { get{ return CalcularGanancia(TipoLlamada.Local);} }
        public float GananciaPorProvincial { get { return CalcularGanancia(TipoLlamada.Provincial); } }
        public float GananciaTotal { get { return CalcularGanancia(TipoLlamada.Todas); } }
        public List<Llamada> Llamadas { get { return this._listaLlamadas; } }
        #endregion

        #region Constructores
        public Centralita(): this("")
        {

        }

        public Centralita(string nombreEmpresa)
        {
            this._razonSocial = nombreEmpresa;
        }
        #endregion

        #region Metodos instancia
        /// <summary>
        /// Retornará el valor de lo recaudado, según el criterio elegido
        /// </summary>
        /// <param name="tipo"></param>
        /// <returns></returns>
        private float CalcularGanancia(TipoLlamada tipo)
        {
            float gananciaLocal=0;
            float gananciaProvincial = 0;
            float retorno = 0;

            foreach (Llamada i in this._listaLlamadas)
            {
                if (i is Local)
                {
                    gananciaLocal += ((Local)i).CostoLlamada;
                }
                else
                {
                    if (i is Provincial)
                    {
                        gananciaProvincial += ((Provincial)i).CostoLlamada;
                    }
                }         
            }
            switch (tipo)
            {
                case TipoLlamada.Local:
                    retorno = gananciaLocal;
                    break;
                case TipoLlamada.Provincial:
                    retorno = gananciaProvincial;
                    break;
                case TipoLlamada.Todas:
                    retorno = gananciaProvincial + gananciaLocal;
                    break;
            }
            return retorno;
        }

        /// <summary>
        /// Mostrará la razón social, la ganancia total, ganancia por llamados locales y provinciales y el detalle de las llamadas realizadas
        /// </summary>
        /// <returns></returns>
        public string Mostrar()
        {
            StringBuilder mensaje = new StringBuilder();
            mensaje.Append("Razon Social: ");
            mensaje.AppendLine(this._razonSocial);
            mensaje.Append("Ganancia Total: ");
            mensaje.AppendLine(this.CalcularGanancia(TipoLlamada.Todas).ToString());
            mensaje.Append("Ganancia Local: ");
            mensaje.AppendLine(this.CalcularGanancia(TipoLlamada.Local).ToString());
            mensaje.Append("Ganancia Provincial: ");
            mensaje.AppendLine(this.CalcularGanancia(TipoLlamada.Provincial).ToString());
            mensaje.Append("Llamadas Realizadas: ");
            foreach (Llamada i in this._listaLlamadas)
            {
                mensaje.AppendLine(i.Mostrar());
            }           
            return mensaje.ToString();
        }

        public void OrdenarLlamadas()
        {
            this._listaLlamadas.Sort(Llamada.OrdenarPorDuracion);
        }
        #endregion

        #region Metodos De Clase
        /// <summary>
        /// Ordena Las llamadas por Razon social
        /// </summary>
        /// <param name="uno"></param>
        /// <param name="dos"></param>
        /// <returns></returns>
        public static int OrdenarLlamadasPorRazonSocial(Centralita uno, Centralita dos)
        {
            int retorno = 0;
            if (string.Compare( uno._razonSocial , dos._razonSocial)==1)
            {
                retorno = 1;
            }
            else
            {
                if (string.Compare(uno._razonSocial, dos._razonSocial) == -1)
                {
                    retorno = -1;
                }
            }
            return retorno;
        }
        #endregion
    }
}
