﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Centralista_9_
{
    public class Llamada
    {
        #region Atributos
        protected float _duracion;
        protected string _nroDestino;
        protected string _nroOrigen;
        #endregion

        #region Propiedades
        public float Duracion { get { return this._duracion; } }
        public string NroDestino { get { return this._nroDestino; } }
        public string NroOrigen { get { return this._nroOrigen; } }
        #endregion

        #region Constructores
        public Llamada(string origen, string destino, float duracion)
        {
            this._duracion = duracion;
            this._nroDestino = destino;
            this._nroOrigen = origen;
        }

        #endregion

        #region Metodos Instancia
        
        public string Mostrar()
        {
            StringBuilder mensaje = new StringBuilder();
            mensaje.Append("Duracion: ");
            mensaje.AppendLine(this.Duracion.ToString());
            mensaje.Append("Nro destino: ");
            mensaje.AppendLine(this.NroDestino);
            mensaje.Append("Nro origen: ");
            mensaje.AppendLine(this.NroOrigen);
            return mensaje.ToString();
        }
        #endregion

        #region Metodos de Clase
        public static int OrdenarPorDuracion(Llamada uno, Llamada dos)
        {
            int retorno = 0;
            if (uno.Duracion > dos.Duracion)
            {
                retorno = 1;
            }
            else
            {
                if (uno.Duracion < dos.Duracion)
                {
                    retorno = -1;
                }
            }
            return retorno;
        }

        #endregion
    }
}
