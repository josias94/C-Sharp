﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Centralista_9_;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Local uno = new Local("1111", "2222", 10, 10);
            Local tres = new Local("3333", "4444", 30, 10);
            Local cinco = new Local("5555", "6666", 50, 10);
            Local siete = new Local("7777", "8888", 70, 10);
            Local nueve = new Local("9999", "1010", 100, 10);

            Provincial dos = new Provincial("2222",Franja.Franja_1,10, "1111");
            Provincial cuatro = new Provincial("4444", Franja.Franja_2, 10, "3333");
            Provincial seis = new Provincial("6666",Franja.Franja_3,10, "5555");
            Provincial ocho = new Provincial("8888",Franja.Franja_1,10, "7777");
            Provincial diez = new Provincial("1010", Franja.Franja_2, 10, "9999");

            Centralita central = new Centralita("TeleFilgo");

            central.Llamadas.Add(uno);
            central.Llamadas.Add(dos);
            central.Llamadas.Add(tres);
            central.Llamadas.Add(cuatro);
            central.Llamadas.Add(cinco);
            central.Llamadas.Add(seis);
            central.Llamadas.Add(siete);
            central.Llamadas.Add(ocho);
            central.Llamadas.Add(nueve);
            central.Llamadas.Add(diez);

            Console.Write(central.Mostrar());

            
        }
    }
}
