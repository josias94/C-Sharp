﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CentralistaV2;

namespace CentralitaWindowsForms
{
    public partial class FrmFinLlamada : FrmLlamada
    {
        public FrmFinLlamada()
        {
            InitializeComponent();
        }
        public FrmFinLlamada(Local llamada):this()
        {
            base.textBox1.Text = llamada.NroOrigen.ToString();
            base.textBox2.Text = llamada.NroDestino.ToString();
            base.txtDuracion.Text = llamada.Duracion.ToString();
            
            //float.TryParse(this.txtCosto.Text, out costo);
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
