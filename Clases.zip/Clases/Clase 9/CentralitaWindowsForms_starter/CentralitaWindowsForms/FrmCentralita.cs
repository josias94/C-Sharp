﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Centralista_9_;

namespace CentralitaWindowsForms
{
    public partial class FrmCentralita : Form
    {
        public Centralita _central;
        public FrmCentralita()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmLocal frmlocal = new FrmLocal();
            frmlocal.ShowDialog();
            if (frmlocal.DialogResult == DialogResult.OK)
            {
                //crear la llamanda u add central
            }

        }

        private void btnProvincial_Click(object sender, EventArgs e)
        {
            FrmProvincial frmPro = new FrmProvincial();
        }
    }
}
