﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CentralistaV2;

namespace CentralitaWindowsForms
{
    public partial class FrmCentralita : Form
    {
        public Centralita _central;
        public FrmCentralita()
        {
            InitializeComponent();
            _central = new Centralita("Filgo");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmLocal frmlocal = new FrmLocal();
            frmlocal.ShowDialog();
            if (frmlocal.DialogResult == DialogResult.OK)
            {
                this._central.AgregarLlamadas(frmlocal.LlamadaLocal);
                this.escribir();
            }
        }

        private void btnProvincial_Click(object sender, EventArgs e)
        {
            FrmProvincial frmPro = new FrmProvincial();
            frmPro.ShowDialog();
            if (frmPro.DialogResult == DialogResult.OK)
            {
                this._central.AgregarLlamadas(frmPro.LlamadaProvincial);
               
                this.escribir();
            }
        }


        private void escribir()
        {
            this.lstVisor.Items.Clear();
            foreach (Llamada i in this._central.Llamadas)
            {
                this.lstVisor.Items.Add(i);
            }
        }

        private void cboOrdenamiento_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(this.cboOrdenamiento.Text == "Mayor a menor")
            {
                this._central.Llamadas.Sort(Llamada.OrdenarPorDuracion);
                this._central.Llamadas.Reverse();
                escribir();
            }
            else
            {
                if (this.cboOrdenamiento.Text == "Menor a mayor")
                {
                    this._central.Llamadas.Sort(Llamada.OrdenarPorDuracion);
                    escribir();
                }
            }
        }

        private void lblLabel_Click(object sender, EventArgs e)
        {

        }

        private void btnFinalizar_Click(object sender, EventArgs e)
        {
            int index = this.lstVisor.SelectedIndex;
            if(index!=-1)
            {
                //FrmFinLlamada frmFin = new FrmFinLlamada(this._central.Llamadas[index]);
                //this._central.Llamadas;
            }
        }
    }
}
