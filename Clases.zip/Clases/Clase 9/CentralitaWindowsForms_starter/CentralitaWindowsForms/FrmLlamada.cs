﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CentralistaV2;

namespace CentralitaWindowsForms
{
    public partial class FrmLlamada : Form
    {
        
        public FrmLlamada()
        {
            InitializeComponent();
            this.txtDuracion.Text = DateTime.Now.ToString();
            this.txtDuracion.ReadOnly = true;
        }


        public void Llamada_Load(object sender, EventArgs e)
        {

        }

        public void label2_Click(object sender, EventArgs e)
        {

        }

        public void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        protected virtual void btnAceptar_Click(object sender, EventArgs e)
        { 
            this.DialogResult = DialogResult.OK;
        }

        protected virtual void btnCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        public void button1_Click(object sender, EventArgs e)
        {

        }

        public void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        public void txtDuracion_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
