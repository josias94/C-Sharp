﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Centralista_9_;

namespace CentralitaWindowsForms
{
    public partial class FrmLlamada : Form
    {
        private Llamada llamada;
        string nroOrigen;
        string nroDestino;
        float duracion;

        public FrmLlamada()
        {
            InitializeComponent();
        }




        public virtual Llamada Llamada
        { 
            get
            {
                return this.llamada;
            }
        }




        private void Llamada_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        protected virtual void btnAceptar_Click(object sender, EventArgs e)
        {
            nroOrigen = this.textBox1.Text;
            nroDestino = this.textBox2.Text;
            float.TryParse(this.txtDuracion.Text, out duracion);

            llamada = new Llamada(nroOrigen, nroDestino, duracion);
            this.DialogResult = DialogResult.OK;
        }

        protected virtual void btnCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
