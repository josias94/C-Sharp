﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CentralistaV2;

namespace CentralitaWindowsForms
{
    public partial class FrmLocal : FrmLlamada
    {
        private Local _llamadaLocal;
        private string nroOrigen;
        private string nroDestino;
        private float duracion;
        protected float costo;

        public FrmLocal()
        {
            InitializeComponent();          
        }

        public Llamada LlamadaLocal
        {
            get
            {
                return this._llamadaLocal;
            }
        }

        private void Local_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void txtCosto_TextChanged(object sender, EventArgs e)
        {

        }

        protected override void btnAceptar_Click(object sender, EventArgs e)
        {
            base.btnAceptar_Click(sender, e);
            nroOrigen = base.textBox1.Text;
            nroDestino = base.textBox2.Text;
            //float.TryParse(base.txtInicio.Text, out duracion);
            float.TryParse(this.txtCosto.Text, out costo);

            _llamadaLocal = new Local(nroOrigen, nroDestino, DateTime.Now, costo);
            this.DialogResult = DialogResult.OK;
        }
        protected override void btnCancelar_Click(object sender, EventArgs e)
        {
            base.btnCancelar_Click(sender, e);
            this.DialogResult = DialogResult.Cancel;
        }

        
        
    }
}
