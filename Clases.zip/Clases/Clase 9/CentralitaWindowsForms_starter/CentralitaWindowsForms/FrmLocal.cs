﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Centralista_9_;

namespace CentralitaWindowsForms
{
    public partial class FrmLocal : FrmLlamada
    {
        private Local _llamadaLocal;
        
        protected float costo;

        public FrmLocal()
        {
            InitializeComponent();
            
        }

        public override Llamada Llamada
        {
            get
            {
                return this._llamadaLocal;
            }
        }

        private void Local_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void txtCosto_TextChanged(object sender, EventArgs e)
        {

        }

        protected override void btnAceptar_Click(object sender, EventArgs e)
        {
            base.btnAceptar_Click(sender, e);

            float.TryParse(this.txtCosto.Text, out costo);

            _llamadaLocal = new Local(base.Llamada, costo);
            this.DialogResult = DialogResult.OK;
        }
        protected override void btnCancelar_Click(object sender, EventArgs e)
        {
            base.btnCancelar_Click(sender, e);
            this.DialogResult = DialogResult.Cancel;
        }

        
        
    }
}
