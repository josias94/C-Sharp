﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Centralista_9_;

namespace CentralitaWindowsForms
{
    public partial class FrmProvincial : FrmLlamada
    {
        private Provincial llamadaProv;

        public FrmProvincial()
        {
            InitializeComponent();
        }

        private void Provincial_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void txtFranja_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        protected override void btnAceptar_Click(object sender, EventArgs e)
        {
            
            base.btnAceptar_Click(sender, e);
        }
    }
}
