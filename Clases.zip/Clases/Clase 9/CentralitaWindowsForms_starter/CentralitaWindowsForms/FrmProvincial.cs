﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CentralistaV2;

namespace CentralitaWindowsForms
{
    public partial class FrmProvincial : FrmLlamada
    {
        private Provincial _llamada;
        string nroOrigen;
        Franja franja;
        string nroDestino;
        float inicio;

        public FrmProvincial()
        {
            
            InitializeComponent();
            foreach(Franja i in Enum.GetValues(typeof(Franja)))
            {
                this.cmbFranja.Items.Add(i);
            }
            this.cmbFranja.SelectedItem = Franja.Franja_1;
            this.cmbFranja.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        public Llamada LlamadaProvincial { get { return this._llamada; } }

        private void Provincial_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void txtFranja_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        protected override void btnAceptar_Click(object sender, EventArgs e)
        {
            base.btnAceptar_Click(sender, e);

            nroOrigen = base.textBox1.Text;
            nroDestino = base.textBox2.Text;
            //float.TryParse(base.txtInicio.Text, out inicio);
            this.franja = (Franja)this.cmbFranja.SelectedItem;

            _llamada = new Provincial(nroOrigen, franja, Convert.ToDateTime(base.txtInicio.Text), nroDestino);
            this.DialogResult = DialogResult.OK;
        }
        protected override void btnCancelar_Click(object sender, EventArgs e)
        {
            base.btnCancelar_Click(sender, e);
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
