﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clase05
{
    public class Tinta
    {
        private ConsoleColor _color;
        private ETipoTinta _tipo;//Comun,China,ConBrillito


        /// <summary>
        /// inicializa los valores en comun y negra
        /// </summary>
        public Tinta()
        {
            this._color = ConsoleColor.Black;
            this._tipo = ETipoTinta.Comun;
        }

        public Tinta(ConsoleColor color):this()
        {
            this._color = color;
        }

        public Tinta(ETipoTinta tipo, ConsoleColor color):this(color)
        {
            this._tipo = tipo;
        }

        private string Mostrar()
        {
            return ("Color: "+this._color.ToString()+"\nTipo: "+this._tipo+"\n");
        }

        public static string Mostrar(Tinta objeto)
        {
            return objeto.Mostrar();
        }

        /*
        public void Mostra()
        {
            Console.ForegroundColor = this._color;
            if(this._color==ConsoleColor.Black)
                Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Color: " + this._color.ToString() + "\nTipo: " + this._tipo + "\n");
        }
        */

        public static bool operator ==(Tinta TintaUno, Tinta TintaDos)
        {
           /*
            bool iguales=false;
            if (TintaUno._color == TintaDos._color && TintaUno._tipo == TintaDos._tipo)
            {
                iguales = true;
            }            
            return iguales;
            */
            return TintaUno._color == TintaDos._color && TintaUno._tipo == TintaDos._tipo;
        }

        public static bool operator !=(Tinta TintaUno, Tinta TintaDos)
        {
            //llamo al metorçdo igual y lo niego
            return !(TintaUno == TintaDos);
        }

       /* public static explicit operator string (Tinta tinta)
        {
            return tinta.Mostrar();
        }
        */
        public static implicit operator string(Tinta tinta)
        {
            return tinta._tipo.ToString();
        }
    }
   
}
