﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Entidades.Clase05;

namespace Rivola.Josias
{
    class Program
    {
        static void Main(string[] args)
        {
            Tinta tintaUno = new Tinta(ETipoTinta.ConBrillito, ConsoleColor.Magenta);
            Tinta tintaDos = new Tinta(ConsoleColor.Red);
            //Tinta tintaDos = new Tinta(ETipoTinta.ConBrillito, ConsoleColor.Magenta);
            Tinta tintaTres = new Tinta();//



            Pluma plumaUno = new Pluma("Filgo", new Tinta(ETipoTinta.ConBrillito, ConsoleColor.Magenta), 10);
            Console.WriteLine("pluma1:\n" + Pluma.Mostrar(plumaUno));


           // Console.WriteLine("Tinta1:\n"+Tinta.Mostrar(tintaUno));
            //Console.WriteLine("Tinta2:\n" + Tinta.Mostrar(tintaDos));
            //Console.WriteLine("Tinta3:\n" + Tinta.Mostrar(tintaTres));
           
           /* if (tintaUno == tintaDos)
            {
                Console.Write("Es igual\n\n");
            }
            else
            {   
                Console.Write("Es distinto\n\n");
            }
            * */


            //Console.Write((string)tintaUno);

            //Console.ForegroundColor = ConsoleColor.Magenta;
            //Console.Write((string)tintaUno);

           
            //jugando
            //tintaUno.Mostra();
            //tintaDos.Mostra();
            //tintaTres.Mostra();
            Console.Read();
        }
    }
}
