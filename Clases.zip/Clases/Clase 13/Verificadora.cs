﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase_13
{
    public static class Verificadora
    {
        public static bool VerificarNumero(Numero num, ETipoNumero tipo)
        {
            bool ret = false;
            switch (tipo)
            {
                case ETipoNumero.Par:
                    if (num.Valor % 2 == 0)
                        ret = true;
                    break;
                case ETipoNumero.Impar:
                    if (num.Valor % 2 != 0)
                        ret = true;
                    break;
                case ETipoNumero.Positivo:
                    if (num.Valor > 0)
                        ret = true;
                    break;
                case ETipoNumero.Negativo:
                    if (num.Valor < 0)
                        ret = true;
                    break;
                case ETipoNumero.Cero:
                    if (num.Valor == 0)
                        ret = true;
                    break;
                default:
                    break;
            }
            return ret;
        }
    }
}
