﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase_13
{
    public class Numero
    {
        #region Atributos
        protected int _numero;
        #endregion

        #region Propiedades
        public int Valor { get{return this._numero;}}
        #endregion

        #region Constructor
        public Numero(int valor)
        {
            this._numero = valor;
        }
	    #endregion

        #region Sobrecargas
        public static int operator+(Numero uno,Numero dos)
        {
            return uno.Valor + dos.Valor;
        }

        public static int operator -(Numero uno, Numero dos)
        {
            return uno.Valor - dos.Valor;
        }

        public static int operator *(Numero uno, Numero dos)
        {
            return uno.Valor * dos.Valor;
        }

        public static double operator /(Numero uno, Numero dos)
        {
            double resultado=0;
            try
            {
                resultado = uno.Valor /dos.Valor;
            }
            catch(DivideByZeroException e)
            {
                Console.WriteLine(e.Message);
            }
            return resultado;
        }
        #endregion
    }
}
