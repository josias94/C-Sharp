﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase_13
{
    public class ColectoraDeNumeros
    {
        #region Atributos
        private List<Numero> _numeros;
        
        #endregion

        #region Constructores
        private ColectoraDeNumeros()
        {
            this._numeros = new List<Numero>();
        }
        public ColectoraDeNumeros(ETipoNumero tipo)
            :this()
        {
            this.Numeros = tipo;
        }
        #endregion

        #region Propiedades
        public ETipoNumero Numeros
        {
            get;
            set;
        }

        public double Suma { get { return CalcularResultado(EResultado.Suma); } }
        public double Resta { get { return CalcularResultado(EResultado.Resta); } }
        public double Multiplicacion { get { return CalcularResultado(EResultado.Multiplicacion); } }
        public double Division { get { return CalcularResultado(EResultado.Division);} }
        #endregion

        #region Metodos
        public double CalcularResultado(EResultado operacion)
        {
            double resultado = this._numeros[0].Valor;
            int i;
            for (i = 1; i < this._numeros.Count;i++)
            {
                switch (operacion)
                {
                    case EResultado.Suma:
                        resultado += this._numeros[i].Valor;
                        break;
                    case EResultado.Resta:
                        resultado -= this._numeros[i].Valor;
                        break;
                    case EResultado.Multiplicacion:
                        resultado *= this._numeros[i].Valor;
                        break;
                    case EResultado.Division:
                        resultado /= this._numeros[i].Valor;
                        break;
                    default:
                        break;
                }
            }
            return resultado;
        }

        
	    #endregion

        #region Sobrecarga
        public static ColectoraDeNumeros operator +(ColectoraDeNumeros lista, Numero num)
        {
            ColectoraDeNumeros auxLista=lista;
            auxLista._numeros.Add(num);
            return auxLista;
        }

        public static ColectoraDeNumeros operator -(ColectoraDeNumeros lista, Numero num)
        {
            ColectoraDeNumeros auxLista = lista;
            foreach (Numero i in auxLista._numeros)
            {
                if (i == num)
                {
                    auxLista._numeros.Remove(i);
                    break;
                }
            }
            return auxLista;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            foreach (Numero i in this._numeros)
            {
                sb.AppendLine(i.Valor.ToString());
            }
            return sb.ToString();
        }
    	#endregion
    }
}
