﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase_3
{
    class Program
    {
        static void Main(string[] args)
        {
            //se inicializan en null o en 0 los atributos
            Auto autoUno = new Auto();
            Auto autoDos = new Auto();
            Auto autoTres = new Auto();
            TimeSpan tiempo;

            //asigno los valores
            //primer auto
            autoUno.marca="Fiat";
            autoUno.patente = "A00D";
            autoUno.precio= 130000;
            //segundo auto
            autoDos.marca = "Ford";
            autoDos.patente = "B00Z";
            autoDos.precio = 80000;
            //tercer auto
            autoTres.marca = "Renault";
            autoTres.patente = "Z056";
            autoTres.precio = 30000;
            //se asigna a auto un la direccion de memoria que tiene auto2
            //cualquier cosa que cambie en auto2 se cambia en auto1
            //autoUno=autoDos;

            //solo se le asigna el valor
            //autoUno.marca = autoDos.marca;

            autoDos.marca = "Renault";
            //ahora es privado
            //Console.WriteLine(autoUno.Mostrar());
            //Console.WriteLine(autoDos.Mostrar());
            Console.WriteLine(Auto.Mostrar(autoUno));
            Console.WriteLine(Auto.Mostrar(autoDos));
            Console.WriteLine(Auto.Mostrar(autoTres));
            Console.WriteLine("Cantidad de autos: {0}",Auto.contInstancias);
            Console.WriteLine("El primer auto ingresado es: " + Auto.FInicio);
            Console.WriteLine("El ultimo auto ingresado es: " + Auto.FFinal);

            //tiempo=Auto.FFinal.CompareTo(Auto.FInicio);
            tiempo = Auto.FFinal - Auto.FInicio;

            Console.WriteLine("El tiempo que paso es {0} milisegundos",tiempo.Milliseconds);
            Console.ReadLine();
        }
    }
}
