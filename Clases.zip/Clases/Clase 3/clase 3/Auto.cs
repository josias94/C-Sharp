﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase_3
{
    class Auto
    {
        //atributos
        public string patente;
        public string marca;
        public float precio;
        //van a compartirse los valores en los obj si son static
        public static int contInstancias;
        public static DateTime FInicio;
        public static DateTime FFinal;

        
        //constructor
        //por convencion se inicializan los atributos en los constructores
        static Auto()//este solo se genera una vez por la primera vez
        {
            Auto.FInicio = DateTime.Now;
        }
        public Auto()
        {
           // if (Auto.contInstancias == 0)
           // {
           //      Auto.FInicio = DateTime.Now;         
           // }
            Auto.FFinal = DateTime.Now;
            Auto.contInstancias++;
        }

        //metodos
        private string Mostrar()
        {
            // string texto;
            // texto="Marca: "+this.marca+"\nPatente: "+this.patente+"\nPrecio: "+this.precio+"\n";
            return "Marca: " + this.marca + "\nPatente: " + this.patente + "\nPrecio: " + this.precio + "\n";
        }
        public static string Mostrar(Auto auto)
        {
            //return "Marca: " + Auto.marca + "\nPatente: " + Auto.patente + "\nPrecio: " + Auto.precio + "\n";
            return auto.Mostrar();
        }





    }
}
