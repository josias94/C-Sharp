﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Clase8;

namespace test_paleta_wf
{
    public partial class FrmTempera : Form
    {
        private Tempera _tempera;
        public FrmTempera()
        {
            InitializeComponent();
            //esto lo puse antes en el combo box pero no andubo porque no cargo
            foreach (ConsoleColor color in Enum.GetValues(typeof(ConsoleColor)))
            {
                this.comboBox1.Items.Add(color);
            }

            this.comboBox1.SelectedItem = ConsoleColor.Black;//negro por defecto
            this.comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;//no permite escribir en el combobox
 
        }
        
        /// <summary>
        /// retorna  el objeto de tipo Tempera
        /// </summary>
        /// <returns>Tempera _tempera</returns>
        public Tempera getTempera()
        {
            return this._tempera;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //tomo los datos  del textbox y casteo
            string marca = this.textBox1.Text;
            ConsoleColor color = (ConsoleColor)this.comboBox1.SelectedItem;
            int cantidad;
            int.TryParse(this.textBox3.Text, out cantidad);
            
            //creo el objeto
            _tempera = new Tempera(color,marca,cantidad);//marca,color,cantidad

            //asigno un valor al DialogResult
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //asigno un valor al DialogResult
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

    }
}
