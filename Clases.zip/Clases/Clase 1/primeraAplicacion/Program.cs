﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace primeraAplicacion
{
    class Program
    {
        static void Main(string[] args)
        {
            int numeroUno;
            int numeroDos;
            int resultado;
            string dato;

            //numeroUno = 10;
            //numeroDos = 90;

            Console.Write("Ingrese numero uno\n");
            //dato = Console.ReadLine();
            //numeroUno = int.Parse(dato);

            while(!int.TryParse(Console.ReadLine(),out numeroUno))
            {
                Console.Write("Error, Reingrese numero uno\n");
            }

            Console.Write("Ingrese numero dos\n");

            while (!(int.TryParse(Console.ReadLine(), out numeroDos)))
            {
                Console.Write("Error, Reingrese numero dos\n");
            }


            resultado = numeroDos + numeroUno;


            Console.Write("El resultado es:"+resultado);
            Console.Read();
 
            
        }
    }
}
