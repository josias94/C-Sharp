﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace _31Octubre2017
{
    public class ProveedorDeDatos
    {
        static SqlConnection conexion;
        static SqlCommand comandos;

        public ProveedorDeDatos()
        {
            try
            {
                ProveedorDeDatos.conexion = new SqlConnection(Properties.Settings.Default.Conexion);
                //ProveedorDeDatos.comandos = new SqlCommand();         
                //Console.WriteLine("Conexion realizada");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            
        }
        //base de datos
        public List<Persona> ObtenerPersonaBD()
        {
            List<Persona> lista = new List<Persona>(); 

            ProveedorDeDatos.comandos = new SqlCommand();
            //configuro nose que
            comandos.Connection = ProveedorDeDatos.conexion;
            comandos.CommandType = CommandType.Text;
            comandos.CommandText = "SELECT id,nombre,apellido,edad FROM personas";
            //abro la conexion
            ProveedorDeDatos.conexion.Open();

            //lector creo
            SqlDataReader dr = comandos.ExecuteReader();
            while(dr.Read())
            {
                lista.Add(new Persona((int)dr[0],(string)dr[1],(string)dr[2],(int)dr[3]));
            }
            
            //ejecutar la consulta
            //recopilar info
            //cerrar
            conexion.Close();
                               
            return lista;
        }






        public static List<Persona> ObtenerPersonaHC()
        {

            Persona p1 = new Persona(1, "Marcos", "Rey", 20);
            Persona p2 = new Persona(1, "Micaela", "Saez", 18);
            Persona p3 = new Persona(1, "Josias", "Rivola", 22);
            List<Persona> lista = new List<Persona>();
            lista.Add(p1);
            lista.Add(p2);
            lista.Add(p3);
            return lista;
        }
        public static Persona ObtenerPersonaPorId(int id)
        {
            List<Persona> lista = new List<Persona>();

            ProveedorDeDatos.comandos = new SqlCommand();
            //configuro nose que
            comandos.Connection = ProveedorDeDatos.conexion;
            comandos.CommandType = CommandType.Text;
            comandos.CommandText = "SELECT id,nombre,apellido,edad FROM personas WHERE id >=5";
            //abro la conexion
            ProveedorDeDatos.conexion.Open();

            //lector creo
            SqlDataReader dr = comandos.ExecuteReader();
            while (dr.Read())
            {
                lista.Add(new Persona((int)dr[0], (string)dr[1], (string)dr[2], (int)dr[3]));
            }

            //ejecutar la consulta
            //recopilar info
            //cerrar
            conexion.Close();

            foreach (Persona p in lista)
            {
                if (p._id == id)
                {
                    return p;
                }
            }
            return null;

            
        }
        public bool AgregarPersona()
        {
            bool retorno = true;
            List<Persona> lista = ProveedorDeDatos.ObtenerPersonaHC();

            ProveedorDeDatos.comandos = new SqlCommand();
            //configuro nose que
            comandos.Connection = ProveedorDeDatos.conexion;
            comandos.CommandType = CommandType.Text;
            comandos.CommandText = "INSERT INTO personas (nombre, apellido, edad) values ('Micaela','Saez',16)";
            ProveedorDeDatos.conexion.Open();
            
            comandos.ExecuteNonQuery();

            ProveedorDeDatos.conexion.Close();


            
            return retorno;
        }
        public static bool ModificarPersona(Persona p1)
        {
            List<Persona> lista = ProveedorDeDatos.ObtenerPersonaHC();
            Persona aux = ObtenerPersonaPorId(p1._id);
            if (aux != null)
            {
                int opcion;
                lista.Remove(aux);
                Console.WriteLine("Que desea modificar\n1-Nombre\n2-Apellido\n3-Edad");
                int.TryParse(Console.ReadLine(), out opcion);
                int edad;
                switch (opcion)
                {
                    case 1:
                        aux = new Persona(aux._id, Console.ReadLine(), aux._apellido, aux._edad);
                        break;
                    case 2:
                        aux = new Persona(aux._id,aux._nombre ,Console.ReadLine(), aux._edad);
                        break;
                    case 3:
                        int.TryParse(Console.ReadLine(),out edad);
                        aux = new Persona(aux._id, aux._nombre, aux._apellido,edad);
                        break;
                    default:
                        break;
                }
                lista.Add(aux);
            }
            return true;
        }
        public static bool EliminarPersona(Persona p1)
        {
            List<Persona> lista = ProveedorDeDatos.ObtenerPersonaHC();
            Persona aux = ObtenerPersonaPorId(p1._id);
            if (p1 != null)
            {
                lista.Remove(aux);
                return true;
            }
            return false;
        }

        public bool DeletePersona()
        {
            bool retorno = true;
            List<Persona> lista = ProveedorDeDatos.ObtenerPersonaHC();

            ProveedorDeDatos.comandos = new SqlCommand();
            //configuro nose que
            comandos.Connection = ProveedorDeDatos.conexion;
            comandos.CommandType = CommandType.Text;
            comandos.CommandText = "DELETE FROM personas WHERE id >=6";
            ProveedorDeDatos.conexion.Open();

            comandos.ExecuteNonQuery();

            ProveedorDeDatos.conexion.Close();



            return retorno;
        }

        

    }
}
