﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _31Octubre2017
{
    public class Persona
    {
        #region Atributos
        public int _id;
        public string _nombre;
        public string _apellido;
        public int _edad;
        #endregion

        #region Constructores
        public Persona(int id, string nombre, string apellido, int edad)
        {
            this._apellido = apellido;
            this._edad = edad;
            this._id = id;
            this._nombre = nombre;
        }
        #endregion

        #region Metodos
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(this._nombre + " " + this._apellido);
            sb.AppendLine("Edad: "+this._edad.ToString());
            sb.AppendLine("Id: " + this._id.ToString());
            return sb.ToString();
        }
        #endregion

        #region Atributos

        #endregion
    }
}
