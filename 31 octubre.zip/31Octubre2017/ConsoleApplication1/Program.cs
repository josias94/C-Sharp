﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _31Octubre2017;
namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            ProveedorDeDatos pd = new ProveedorDeDatos();

            List<Persona> lista = pd.ObtenerPersonaBD();

            Console.WriteLine("Listado de personas:\n");
            foreach (Persona p in lista)
            {
                Console.WriteLine(p.ToString());
            }

            
            pd.AgregarPersona();

            lista = pd.ObtenerPersonaBD();

            Console.WriteLine("Listado de personas agregando a mica:\n");
            foreach (Persona p in lista)
            {
                Console.WriteLine(p.ToString());
            }
            
            pd.DeletePersona();

            lista = pd.ObtenerPersonaBD();

            Console.WriteLine("Listado de personas despues de borrar a mica:\n");
            foreach (Persona p in lista)
            {
                Console.WriteLine(p.ToString());
            }
            


            
            //try
            //{
            //    Console.WriteLine("ID que existe" + ProveedorDeDatos.ObtenerPersonaPorId(1).ToString());
            //}
            //catch (Exception e)
            //{
            //    Console.WriteLine("No existe el id");
            //}
            
            //Console.WriteLine("ID que existe" + ProveedorDeDatos.ObtenerPersonaPorId(10).ToString());

            
            //lista.Add(nueva);

            Console.ReadLine();
        }

        
    }
}
